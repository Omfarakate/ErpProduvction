import { NextResponse } from "next/server";

export async function GET(request) {
  return handler(request);
}

export async function POST(request) {
  return handler(request);
}

async function handler(request) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const path = searchParams.get("path");

    if (!path) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing path parameter",
        },
        { status: 400 }
      );
    }

    const decodedUrl = Buffer.from(path, "base64").toString("utf-8");
    // console.log("Relay forwarding to:", decodedUrl);
    const fetchOptions = {
      method: request.method,
      headers: {
        "Content-Type": "application/json",
      },
    };

    // Handle POST body
    if (request.method == "POST") {
      const body = await request.json().catch(() => null);

      if (body) {
        fetchOptions.body = JSON.stringify(body);
      }
    }

    const response = await fetch(decodedUrl, fetchOptions);

    // Get response text first
    const text = await response.text();

    let data;

    try {
      data = JSON.parse(text);
    } catch {
      // If response is HTML/text
      return NextResponse.json(
        {
          success: false,
          error: "API did not return JSON",
          raw: text.substring(0, 200),
        },
        { status: 500 }
      );
    }

    return NextResponse.json(data, {
      status: response.status,
    });
  } catch (error) {
    console.error("Relay Error:", error);

    return NextResponse.json(
      {
        success: false,
        error: error.message || "Internal Server Error",
      },
      { status: 500 }
    );
  }
}