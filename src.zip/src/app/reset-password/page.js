"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { resetPassword } from "../lib/api";
import { getStoredUser } from "@/lib/auth";
import Logo from "@/components/common/logo";
import InputField from "@/components/common/inputFields";
import Footer from "@/components/common/footer";
import { toast } from "@/lib/toast";

export default function ResetPasswordPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  useEffect(() => {
    const storedUser = getStoredUser();
    if (storedUser) {
      router.replace("/dashboard");
      return;
    }

    const emailParam = searchParams.get("email");
    if (emailParam) {
      setEmail(decodeURIComponent(emailParam));
    } else {
      router.replace("/forgot-password");
    }
  }, [searchParams, router]);

  const validate = () => {
    const e = {};
    if (!email.trim()) e.email = "Email is required";
    if (!otp.trim()) e.otp = "OTP is required";
    if (!newPassword) e.newPassword = "Password is required";
    else if (newPassword.length < 6) e.newPassword = "Password must be at least 6 characters";
    if (newPassword !== confirmPassword) e.confirmPassword = "Passwords do not match";
    return e;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      toast.error("Please fix the form errors");
      return;
    }
    setIsLoading(true);
    try {
      await resetPassword(email, otp, newPassword);
      setResetSuccess(true);
      toast.success("Password reset successfully!");
      setTimeout(() => router.push("/login"), 2000);
    } catch (err) {
      console.error("Reset password error:", err);
      const msg = err.message || "Failed to reset password";
      setErrors({ submit: msg });
      toast.error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const setField = (field, value) => {
    if (field === "email") setEmail(value);
    else if (field === "otp") setOtp(value);
    else if (field === "newPassword") setNewPassword(value);
    else if (field === "confirmPassword") setConfirmPassword(value);
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-[420px] p-8">
        <div className="mb-7"><Logo /></div>

        {!resetSuccess ? (
          <>
            <h1 className="text-xl font-bold text-gray-900 mb-2">Reset your password</h1>
            <p className="text-sm text-gray-500 mb-6 leading-relaxed">
              Enter the OTP sent to your email and set a new password.
            </p>
            {errors.submit && <p className="text-sm text-red-500 mb-4">{errors.submit}</p>}
            <form onSubmit={handleSubmit} noValidate>
              <InputField
                label="Email address"
                id="email"
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setField("email", e.target.value)}
                error={errors.email}
                disabled
              />
              <InputField
                label="OTP"
                id="otp"
                placeholder="Enter 6-digit OTP"
                value={otp}
                onChange={(e) => setField("otp", e.target.value)}
                error={errors.otp}
                maxLength="6"
              />
              <InputField
                label="New Password"
                id="newPassword"
                type="password"
                placeholder="New password"
                value={newPassword}
                onChange={(e) => setField("newPassword", e.target.value)}
                error={errors.newPassword}
              />
              <InputField
                label="Confirm Password"
                id="confirmPassword"
                type="password"
                placeholder="Confirm password"
                value={confirmPassword}
                onChange={(e) => setField("confirmPassword", e.target.value)}
                error={errors.confirmPassword}
              />
              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-4 py-[13px] bg-blue-600 hover:bg-blue-700 disabled:opacity-70 disabled:cursor-not-allowed text-white text-[15px] font-semibold rounded-md transition-all flex items-center justify-center min-h-[46px]"
              >
                {isLoading ? (
                  <span className="inline-block w-[18px] h-[18px] border-2 border-white/40 border-t-white rounded-full animate-spin" />
                ) : "Reset Password"}
              </button>
            </form>
          </>
        ) : (
          <div className="text-center py-4">
            <div className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2.5">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            </div>
            <h2 className="text-lg font-bold text-gray-900 mb-2">Password reset successful!</h2>
            <p className="text-sm text-gray-500 mb-6">
              Your password has been reset. You can now log in with your new password.
            </p>
            <Link
              href="/login"
              className="inline-block w-full py-[13px] bg-blue-600 hover:bg-blue-700 text-white text-[15px] font-semibold rounded-md transition-all text-center"
            >
              Back to Login
            </Link>
          </div>
        )}

        <p className="text-center text-[13.5px] text-gray-500 mt-6">
          Remember your password?{" "}
          <Link href="/login" className="font-semibold text-blue-600 hover:underline">
            Back to Login
          </Link>
        </p>
      </div>
      </div>
      <Footer />
    </div>
  );
}
