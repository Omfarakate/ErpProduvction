"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { loginUser } from "../lib/api";
import { isSuperAdminUser, storeUser, getStoredUser } from "@/lib/auth";
import Logo from "@/components/common/logo";
import Illustration from "@/components/common/illustration";
import InputField from "@/components/common/inputFields";
import Footer from "@/components/common/footer";
import { toast } from "@/lib/toast";
import { parseApiError } from "@/lib/errorHandler";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    const storedUser = getStoredUser();
    if (storedUser) {
      console.log("[LOGIN] Auto-login detected for:", storedUser?.email);
      const isAdmin = isSuperAdminUser(storedUser);
      console.log("[LOGIN] Redirecting to", isAdmin ? "/users" : "/dashboard");
      router.replace(isAdmin ? "/users" : "/dashboard");
    } else {
      console.log("[LOGIN] No stored user, showing login page");
      setIsChecking(false);
    }
  }, [router]);

  const validate = () => {
    const e = {};
    if (!email.trim()) e.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = "Enter a valid email";
    if (!password) e.password = "Password is required";
    return e;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }
    setErrors({});
    setIsLoading(true);
    try {
      console.log("[LOGIN] Attempting login with rememberMe:", rememberMe);
      const result = await loginUser({ email, password });

      if (!result || result.error) {
        const msg = result?.error || "Please check your email and password.";
        toast.error(msg);
        return;
      }

      storeUser(result, rememberMe);
      toast.success("Login successful!");
      console.log("[LOGIN] Success. Redirecting...");

      const isAdmin = isSuperAdminUser(result);
      setTimeout(() => {
        router.push(isAdmin ? "/dashboard" : "/dashboard");
      }, 300);
    } catch (err) {
      console.error("[LOGIN] Error:", err);
      const msg = parseApiError(err);
      toast.error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  if (isChecking) return null;

  return (
    <div className="flex flex-col min-h-screen w-full">
      <div className="flex flex-1 w-full">
        <div className="flex flex-col w-full md:w-[46%] bg-white px-8 md:px-12 py-8">
          <Logo />
          <div className="flex flex-col justify-center flex-1 max-w-[360px] pb-14 mx-auto w-full">
            <h1 className="text-[22px] font-bold text-gray-900 mb-7 tracking-tight leading-snug">
              Log in to Production Planning
            </h1>
            <form onSubmit={handleSubmit} noValidate>
              <InputField
                label="Email"
                id="email"
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setErrors((p) => ({ ...p, email: undefined })); }}
                error={errors.email}
              />
              <InputField
                label="Password"
                id="password"
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => { setPassword(e.target.value); setErrors((p) => ({ ...p, password: undefined })); }}
                error={errors.password}
              />
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-[13px] bg-blue-600 hover:bg-blue-700 disabled:opacity-70 disabled:cursor-not-allowed text-white text-[15px] font-semibold rounded-md transition-all flex items-center justify-center min-h-[46px] mt-1"
              >
                {isLoading ? (
                  <span className="inline-block w-[18px] h-[18px] border-2 border-white/40 border-t-white rounded-full animate-spin" />
                ) : "Login"}
              </button>
              <div className="flex items-center justify-between mt-3.5">
                <label className="flex items-center gap-2 cursor-pointer select-none group">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => {
                      setRememberMe(e.target.checked);
                      console.log("[LOGIN] Remember me toggled:", e.target.checked);
                    }}
                    className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
                  />
                  <span className="text-[13.5px] text-gray-500 group-hover:text-gray-700 transition-colors">
                    Remember me
                  </span>
                  <span 
                    title={rememberMe ? "You'll stay logged in on this device" : "Session clears when you close the browser"}
                    className="text-[11px] text-gray-400 ml-1"
                  >
                    {/* {rememberMe ? "(persistent)" : "(session)"} */}
                  </span>
                </label>
                <Link href="/forgot-password" className="text-[13.5px] font-bold text-gray-900 hover:text-blue-600 transition-colors">
                  Forgot Password?
                </Link>
              </div>
            </form>
          </div>
        </div>
        <div
          className="hidden md:flex flex-1 relative items-center justify-center overflow-hidden"
          style={{ background: "linear-gradient(135deg,#2563eb 0%,#1e40af 60%,#1d4ed8 100%)" }}
        >
          <div className="absolute inset-0" style={{ background: "linear-gradient(145deg,rgba(255,255,255,0.07) 0%,transparent 50%)" }} />
          <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(circle,rgba(255,255,255,0.08) 1px,transparent 1px)", backgroundSize: "28px 28px" }} />
          <div className="relative z-10 flex items-center justify-center w-full">
            <Illustration />
          </div>
        </div>
      </div>
      {/* <Footer /> */}
    </div>
  );
}
