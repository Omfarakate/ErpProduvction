"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { forgotPassword } from "../lib/api";
import { getStoredUser } from "@/lib/auth";
import Logo from "@/components/common/logo";
import InputField from "@/components/common/inputFields";
import Footer from "@/components/common/footer";
import { toast } from "@/lib/toast";

export default function ForgotPasswordPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    const storedUser = getStoredUser();
    if (storedUser) {
      router.replace("/dashboard");
    } else {
      setIsChecking(false);
    }
  }, [router]);

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!email.trim()) { setError("Email is required"); return; }
    if (!/\S+@\S+\.\S+/.test(email)) { setError("Enter a valid email"); return; }
    setError("");
    setIsLoading(true);
    try {
      await forgotPassword(email);
      setSubmitted(true);
      toast.success("Reset instructions sent to your email");
    } catch (err) {
      const msg = err.message || "Request failed. Please try again.";
      setError(msg);
      toast.error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  if (isChecking) return null;

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-[420px] p-8">
        <div className="mb-7"><Logo /></div>

        {!submitted ? (
          <>
            <h1 className="text-xl font-bold text-gray-900 mb-2">Reset your password</h1>
            <p className="text-sm text-gray-500 mb-6 leading-relaxed">
              Enter your email address and we&apos;ll send you instructions to reset your password.
            </p>
            <form onSubmit={handleSubmit} noValidate>
              <InputField
                label="Email address"
                id="email"
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setError(""); }}
                error={error}
              />
              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-2 py-[13px] bg-blue-600 hover:bg-blue-700 disabled:opacity-70 disabled:cursor-not-allowed text-white text-[15px] font-semibold rounded-md transition-all flex items-center justify-center min-h-[46px]"
              >
                {isLoading ? (
                  <span className="inline-block w-[18px] h-[18px] border-2 border-white/40 border-t-white rounded-full animate-spin" />
                ) : "Send Reset Instructions"}
              </button>
            </form>
          </>
        ) : (
          <div className="text-center py-4">
            <div className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2.5">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            </div>
            <h2 className="text-lg font-bold text-gray-900 mb-2">Check your email</h2>
            <p className="text-sm text-gray-500 mb-6">
              We&apos;ve sent an OTP to <strong>{email}</strong>.
            </p>
            <button
              onClick={() => router.push(`/reset-password?email=${encodeURIComponent(email)}`)}
              className="w-full py-[13px] bg-blue-600 hover:bg-blue-700 text-white text-[15px] font-semibold rounded-md transition-all"
            >
              Enter OTP & Reset Password
            </button>
          </div>
        )}

        <p className="text-center text-[13.5px] text-gray-500 mt-6">
          Remember your password?{" "}
          <Link href="/login" className="font-semibold text-blue-600 hover:underline">
            Back to Login
          </Link>
        </p>
      </div>
      </div>
      <Footer />
    </div>
  );
}
