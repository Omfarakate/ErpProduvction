"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/common/header";
import Footer from "@/components/common/footer";
import { toast } from "@/lib/toast";

function getUser() {
  if (typeof window === "undefined") return null;
  const stored = localStorage.getItem("pp_user") || sessionStorage.getItem("pp_user");
  return stored ? JSON.parse(stored) : null;
}

function isImpersonating() {
  if (typeof window === "undefined") return false;
  return localStorage.getItem("pp_impersonating") === "true";
}

function restoreAdminSession(router) {
  const adminSession = localStorage.getItem("pp_admin_session");
  if (!adminSession) return false;
  localStorage.setItem("pp_user", adminSession);
  sessionStorage.removeItem("pp_user");
  localStorage.removeItem("pp_admin_session");
  localStorage.removeItem("pp_impersonating");
  router.push("/users");
  return true;
}

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const u = getUser();
    if (!u) {
      router.replace("/login");
      return;
    }
    setUser(u);
  }, [router]);

  const handleLogout = () => {
    if (isImpersonating()) {
      restoreAdminSession(router);
    } else {
      localStorage.removeItem("pp_user");
      sessionStorage.removeItem("pp_user");
      localStorage.removeItem("pp_admin_session");
      localStorage.removeItem("pp_impersonating");
      toast.success("Logged out successfully");
      router.replace("/login");
    }
  };

  if (!user) return null;

  // const fullName = [user?.firstName, user?.lastName].filter(Boolean).join(" ") || user?.userName || user?.email;
  // const initials = [user?.firstName?.[0], user?.lastName?.[0]].filter(Boolean).join("").toUpperCase();
  // const isSuperAdmin = user?.email === "omifarakate@gmail.com" || user?.role === "superAdmin" || user?.isSuperAdmin === true;

  return (
    <div className="min-h-screen bg-[#f7f8fa] flex flex-col">
      <Header user={user} onLogout={handleLogout} />

      <main className="flex-1 px-4 sm:px-6 py-8 w-full">
        <div className="max-w-6xl mx-auto">
          {/* Welcome Card */}
          {/* <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 md:p-10 text-white mb-8 shadow-lg overflow-hidden relative">
            <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -mr-20 -mt-20"></div>
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full -ml-16 -mb-16"></div>
            <div className="relative z-10 flex items-start justify-between">
              <div className="flex-1">
                <h1 className="text-4xl font-bold mb-2">Welcome back, {fullName}! 👋</h1>
                <p className="text-blue-100 text-lg">You have full access to Production Planning Platform</p>
              </div>
              <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center text-3xl font-bold backdrop-blur-sm hidden sm:flex">
                {initials}
              </div>
            </div>
          </div> */}

          {/* Quick Actions Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {/* Profile Card */}
            <div className="bg-white rounded-xl border border-gray-100 hover:shadow-md hover:border-blue-200 transition-all duration-300 overflow-hidden group">
              <div className="h-1 bg-gradient-to-r from-blue-500 to-blue-600"></div>
              <div className="p-6">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-200 transition-colors">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1 text-lg">Profile</h3>
                <p className="text-sm text-gray-500 mb-4">View and manage your profile information</p>
                <button
                  onClick={() => router.push("")}
                  className="text-blue-600 hover:text-blue-700 text-sm font-medium transition-colors inline-flex items-center gap-1">
                  Go to Profile
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                  </svg>
                </button>
              </div>
            </div>

            {/* Security Card */}
            <div className="bg-white rounded-xl border border-gray-100 hover:shadow-md hover:border-green-200 transition-all duration-300 overflow-hidden group">
              <div className="h-1 bg-gradient-to-r from-green-500 to-green-600"></div>
              <div className="p-6">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-green-200 transition-colors">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1 text-lg">Security</h3>
                <p className="text-sm text-gray-500 mb-4">Change your password and security settings</p>
                <button
                  onClick={() => router.push("/change-password")}
                  className="text-green-600 hover:text-green-700 text-sm font-medium transition-colors inline-flex items-center gap-1">
                  Change Password
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                  </svg>
                </button>
              </div>
            </div>

             <div className="bg-white rounded-xl border border-gray-100 hover:shadow-md hover:border-purple-200 transition-all duration-300 overflow-hidden group">
                <div className="h-1 bg-gradient-to-r from-purple-500 to-purple-600"></div>
                <div className="p-6">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-purple-200 transition-colors">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#9333ea" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                      <circle cx="9" cy="7" r="4"></circle>
                      <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                      <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1 text-lg">Users</h3>
                  <p className="text-sm text-gray-500 mb-4">Manage all users in the system</p>
                  <button
                    onClick={() => router.push("/users")}
                    className="text-purple-600 hover:text-purple-700 text-sm font-medium transition-colors inline-flex items-center gap-1">
                    Go to Users
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="9 18 15 12 9 6"></polyline>
                    </svg>
                  </button>
                </div>
              </div>
            {/* Users Management Card - Admin Only */}
            {/* {isSuperAdmin && (
              <div className="bg-white rounded-xl border border-gray-100 hover:shadow-md hover:border-purple-200 transition-all duration-300 overflow-hidden group">
                <div className="h-1 bg-gradient-to-r from-purple-500 to-purple-600"></div>
                <div className="p-6">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-purple-200 transition-colors">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#9333ea" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                      <circle cx="9" cy="7" r="4"></circle>
                      <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                      <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1 text-lg">Users</h3>
                  <p className="text-sm text-gray-500 mb-4">Manage all users in the system</p>
                  <button
                    onClick={() => router.push("/users")}
                    className="text-purple-600 hover:text-purple-700 text-sm font-medium transition-colors inline-flex items-center gap-1">
                    Go to Users
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="9 18 15 12 9 6"></polyline>
                    </svg>
                  </button>
                </div>
              </div>
            )} */}
          </div>

          {/* Account Info Card */}
          {/* <div className="bg-white rounded-xl border border-gray-100 shadow-sm">
            <div className="border-b border-gray-100 px-6 py-4">
              <h2 className="text-lg font-semibold text-gray-900">Account Information</h2>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <p className="text-sm text-gray-600 mb-2">Email Address</p>
                  <p className="text-gray-900 font-medium break-all">{user?.email}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-2">Username</p>
                  <p className="text-gray-900 font-medium">{user?.userName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-2">Full Name</p>
                  <p className="text-gray-900 font-medium">{fullName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-2">Account Type</p>
                  <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                    isSuperAdmin 
                      ? "bg-purple-100 text-purple-800" 
                      : "bg-blue-100 text-blue-800"
                  }`}>
                    {isSuperAdmin ? "🔐 Administrator" : "👤 User"}
                  </span>
                </div>
              </div>
            </div>
          </div> */}
        </div>
      </main>

      <Footer />
    </div>
  );
}
