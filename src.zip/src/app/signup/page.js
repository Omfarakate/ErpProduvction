"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Logo from "@/components/common/logo";
import StepBadge from "@/components/badge/stepBadge";
import InputField from "@/components/common/inputFields";
import Footer from "@/components/common/footer";
import "react-phone-number-input/style.css";
import PhoneInput from "react-phone-number-input";
import { parsePhoneNumber } from "react-phone-number-input";
import {
  step1Schema,
  step2Schema,
  fullSignupSchema,
} from "@/components/validation/zodValidation";
import { signupUser, fetchCompanies, fetchGroups } from "../lib/api";
import { toast } from "@/lib/toast";
import { parseApiError, mapFormErrors } from "@/lib/errorHandler";

const STEPS = ["Account", "Profile", "Confirm"];

export default function SignupPage() {
  const router = useRouter();

  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState("");
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState({});

  const [companies, setCompanies] = useState([]);
  const [groups, setGroups] = useState([]);
  const [dropdownLoading, setDropdownLoading] = useState(false);
  const [dropdownError, setDropdownError] = useState("");

  const [form, setForm] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    firstName: "",
    lastName: "",
    userName: "",
    dialCode: "",
    phoneNumber: "",
    birthDate: "",
    uploadedFile: null,
    companyId: "",
    groupId: "",
  });

  useEffect(() => {
    if (step === 3) {
      setDropdownLoading(true);
      setDropdownError("");

      Promise.all([fetchCompanies(), fetchGroups()])
        .then(([companiesData, groupsData]) => {
          setCompanies(companiesData);
          setGroups(groupsData);
        })
        .catch((err) => {
          setDropdownError(err.message || "Failed to load dropdown data");
        })
        .finally(() => setDropdownLoading(false));
    }
  }, [step]);

  const set = (field) => (e) => {
    setForm((f) => ({ ...f, [field]: e.target.value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const handleFileChange = (e) => {
    setForm((prev) => ({ ...prev, uploadedFile: e.target.files[0] }));
  };

  const mapZodErrors = (err) => {
    const fieldErrors = {};

    if (err?.issues) {
      err.issues.forEach((e) => {
        fieldErrors[e.path[0]] = e.message;
      });
    }
    return fieldErrors;
  };

  const nextStep = () => {
    try {
      if (step === 1) step1Schema.parse(form);
      if (step === 2) step2Schema.parse(form);
      setErrors({});
      setStep((s) => s + 1);
    } catch (err) {
      setErrors(mapZodErrors(err));
    }
  };

  const prevStep = () => setStep((s) => s - 1);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setApiError("");

    if (!form.companyId) {
      setErrors((prev) => ({ ...prev, companyId: "Please select a company" }));
      return;
    }
    if (!form.groupId) {
      setErrors((prev) => ({ ...prev, groupId: "Please select a group" }));
      return;
    }

    try {
      fullSignupSchema.parse(form);
      setIsLoading(true);

      await signupUser({
        ...form,
        companyId: Number(form.companyId),
        groupId: Number(form.groupId),
      });

      toast.success("Account created successfully!");
      setSuccess(true);
      setTimeout(() => router.push("/login"), 2500);
    } catch (err) {
      if (err.issues) {
        setErrors(mapZodErrors(err));
        toast.error("Please fix the form errors");
      } else {
        // Use error handler to map raw DB errors to user-friendly messages
        const msg = parseApiError(err);
        setApiError(msg);
        toast.error(msg);
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="flex flex-col min-h-screen">
        <div className="flex-1 flex items-center justify-center">
          <div className="bg-white p-10 rounded-xl shadow-xl">
            <h2 className="text-black text-2xl font-bold mb-2">
              Account Created!
            </h2>
            <p className="text-gray-500">Redirecting to login...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="flex-1 flex justify-center items-center px-4 py-10">
        <div className="bg-white w-full max-w-[480px] rounded-2xl shadow-xl p-8">
        <Logo />

        <div className="mt-6 mb-7">
          <h1 className="text-black text-2xl font-bold">
            Create An User account
          </h1>
          <p className="text-sm text-gray-500 mt-1">Join Production Planning</p>
        </div>

        {/* Steps */}
        <div className="flex items-center gap-2 mb-8">
          {STEPS.map((label, i) => (
            <div key={i} className="flex items-center gap-2">
              <StepBadge step={i + 1} current={step} />
              <span
                className={`text-xs ${
                  i + 1 === step ? "text-blue-600" : "text-gray-400"
                }`}
              >
                {label}
              </span>
            </div>
          ))}
        </div>

        {apiError && (
          <div className="mb-4 p-3 rounded bg-red-50 text-red-500 text-sm">
            {apiError}
          </div>
        )}

        {step === 1 && (
          <>
            <InputField
              label="Email"
              id="email"
              type="email"
              value={form.email}
              onChange={set("email")}
              error={errors.email}
              required
            />
            <InputField
              label="Password"
              id="password"
              type="password"
              value={form.password}
              onChange={set("password")}
              error={errors.password}
              required
            />

            <InputField
              label="Confirm Password"
              id="confirmPassword"
              type="password"
              value={form.confirmPassword}
              onChange={set("confirmPassword")}
              error={errors.confirmPassword}
              required
            />
            <button
              onClick={nextStep}
              className="w-full bg-blue-600 text-white py-3 rounded-md"
            >
              Continue
            </button>
          </>
        )}

        {step === 2 && (
          <>
            <InputField
              label="First Name"
              id="firstName"
              value={form.firstName}
              onChange={set("firstName")}
              error={errors.firstName}
              required
            />
            <InputField
              label="Last Name"
              id="lastName"
              value={form.lastName}
              onChange={set("lastName")}
              error={errors.lastName}
              required
            />
            <InputField
              label="Username"
              id="userName"
              value={form.userName}
              onChange={set("userName")}
              error={errors.userName}
              required
            />
            {/* Phone Number Input */}
            <div className="flex flex-col gap-1 mb-4">
              <label className="text-[13px] font-medium text-gray-800">
                Phone
              </label>

              <PhoneInput
                international
                defaultCountry="IN"
                value={
                  form.dialCode && form.phoneNumber
                    ? `${form.dialCode}${form.phoneNumber}`
                    : ""
                }
                onChange={(value) => {
                  if (!value) {
                    setForm((prev) => ({
                      ...prev,
                      dialCode: "",
                      phoneNumber: "",
                    }));
                    return;
                  }

                  const phoneData = parsePhoneNumber(value);
                  const dialCode = phoneData?.countryCallingCode
                    ? `+${phoneData.countryCallingCode}`
                    : "";
                  const nationalNum = phoneData?.nationalNumber || value || "";

                  setForm((prev) => ({
                    ...prev,
                    dialCode: dialCode,
                    phoneNumber: nationalNum,
                  }));

                  setErrors((prev) => ({
                    ...prev,
                    phoneNumber: "",
                  }));
                }}
                className="border rounded-md px-3 py-2 text-sm text-black"
              />

              {errors.phoneNumber && (
                <p className="text-red-500 text-xs">{errors.phoneNumber}</p>
              )}
            </div>
            {/* <InputField
              label="Birth Date"
              id="birthDate"
              type="date"
              value={form.birthDate}
              onChange={set("birthDate")}
              error={errors.birthDate}
              required
            /> */}
            <InputField
              label="Date of Birth"
              id="birthDate"
              type="date"
              value={form.birthDate}
              onChange={set("birthDate")}
              error={errors.birthDate}
              required
            />

            <div className="flex flex-col gap-1 mb-4">
              <label className="text-[13px] font-medium text-gray-800">
                Profile Photo
              </label>

              <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="text-black border rounded-md px-3 py-2 text-sm"
              />
            </div>
            <div className="flex gap-3">
              <button
                onClick={prevStep}
                className="text-black flex-1 border py-3 rounded-md"
              >
                Back
              </button>

              <button
                onClick={nextStep}
                className="flex-1 bg-blue-600 text-white py-3 rounded-md"
              >
                Continue
              </button>
            </div>
          </>
        )}

        {step === 3 && (
          <form onSubmit={handleSubmit}>
            {/* Summary */}
            <div className="text-black bg-gray-50 p-4 rounded-xl mb-5 text-sm space-y-1">
              <div className="font-medium">{form.email}</div>
              <div>
                {form.firstName} {form.lastName}
              </div>
              <div className="text-gray-500">@{form.userName}</div>
              <div className="text-gray-500">{form.phoneNumber}</div>
              {form.uploadedFile && (
                <div className="text-gray-400 text-xs">
                  📎 {form.uploadedFile.name}
                </div>
              )}
            </div>

            {dropdownLoading ? (
              <p className="text-sm text-gray-400 mb-4">Loading options...</p>
            ) : dropdownError ? (
              <p className="text-sm text-red-500 mb-4">{dropdownError}</p>
            ) : (
              <>
                <div className="flex flex-col gap-1 mb-4">
                  <label className="text-[13px] font-medium text-gray-800">
                    Company <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={form.companyId}
                    onChange={set("companyId")}
                    className="text-black border rounded-md px-3 py-2 text-sm bg-white"
                  >
                    <option value="">— Select Company —</option>
                    {companies.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.companyName}
                      </option>
                    ))}
                  </select>
                  {errors.companyId && (
                    <p className="text-red-500 text-xs">{errors.companyId}</p>
                  )}
                </div>

                <div className="flex flex-col gap-1 mb-6">
                  <label className="text-[13px] font-medium text-gray-800">
                    Role / Group <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={form.groupId}
                    onChange={set("groupId")}
                    className="text-black border rounded-md px-3 py-2 text-sm bg-white"
                  >
                    <option value="">— Select Group —</option>
                    {groups.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.groupName}
                      </option>
                    ))}
                  </select>
                  {errors.groupId && (
                    <p className="text-red-500 text-xs">{errors.groupId}</p>
                  )}
                </div>
              </>
            )}

            <div className="flex gap-3">
              <button
                type="button"
                onClick={prevStep}
                className="text-black flex-1 border py-3 rounded-md"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={isLoading || dropdownLoading}
                className="flex-1 bg-blue-600 text-white py-3 rounded-md disabled:opacity-60"
              >
                {isLoading ? "Creating..." : "Create Account"}
              </button>
            </div>
          </form>
        )}

        <p className="text-center text-sm mt-5 text-gray-500">
          Already have an account?{" "}
          <Link href="/login" className="text-blue-600 font-semibold">
            Login
          </Link>
        </p>
      </div>
      </div>
      <Footer />
    </div>
  );
}
