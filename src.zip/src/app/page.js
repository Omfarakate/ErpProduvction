"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { getStoredUser, isSuperAdminUser } from "@/lib/auth";

export default function Home() {
  const router = useRouter();

  useEffect(() => {
    const storedUser = getStoredUser();
    if (storedUser) {
      const isAdmin = isSuperAdminUser(storedUser);
      router.replace(isAdmin ? "/users" : "/dashboard");
    } else {
      router.replace("/login");
    }
  }, [router]);

  return null;
}
