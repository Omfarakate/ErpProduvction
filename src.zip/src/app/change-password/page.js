"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/common/header";
import InputField from "@/components/common/inputFields";
import { toast } from "@/lib/toast";
import { CallApi } from "@/lib/general";
import { parseApiError } from "@/lib/errorHandler";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

function getUser() {
  if (typeof window === "undefined") return null;
  const stored = localStorage.getItem("pp_user") || sessionStorage.getItem("pp_user");
  return stored ? JSON.parse(stored) : null;
}

export default function ChangePasswordPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({ currentPassword: "", newPassword: "", confirmPassword: "" });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const u = getUser();
    if (!u) { router.replace("/login"); return; }
    setUser(u);
  }, [router]);

  const setField = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const validate = () => {
    const e = {};
    if (!form.currentPassword) e.currentPassword = "Please enter your correct current password";
    if (!form.newPassword) e.newPassword = "Please enter a new password";
    else if (form.newPassword.length < 6) e.newPassword = "Password must be at least 6 characters";
    if(form.newPassword && form.currentPassword === form.newPassword) {
      e.newPassword = "New password cannot be the same as current password";
    }
    if (!form.confirmPassword) e.confirmPassword = "Please confirm your new password";
    else if (form.newPassword !== form.confirmPassword) e.confirmPassword = "Passwords do not match";
    return e;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      // toast.error("Please fix the form errors");
      return;
    }
    setIsLoading(true);
    try {
      console.log("pass change form data:", form);
      console.log(`${BASE_URL}/user/change-password`);

      const url = `${BASE_URL}/user/change-password`;
      const result = await CallApi(url, {
        method: "POST",
        body: {
          email: user.email,
          currentPassword: form.currentPassword,
          newPassword: form.newPassword,
          confirmPassword: form.confirmPassword
        },
      });
      const res = result?.settings || result;
      if (res?.success === 1 || res?.success === true) {
        toast.success("Password changed successfully!");
        setForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
        setTimeout(() => router.push("/dashboard"), 1000);
      } else {
        const msg = parseApiError(res?.message || "Failed to change password");
        toast.error(msg);
        setErrors({ currentPassword: msg });
      }
    } catch (err) {
      const msg = parseApiError(err);
      toast.error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("pp_user");
    sessionStorage.removeItem("pp_user");
    toast.success("Logged out");
    router.replace("/login");
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#f7f8fa] flex flex-col">
      <Header user={user} onLogout={handleLogout} />
      <main className="flex-1 flex items-start justify-center px-4 py-10">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 w-full max-w-[440px] p-8">
          <div className="mb-6">
            <h1 className="text-xl font-bold text-gray-900">Change Password</h1>
            <p className="text-sm text-gray-500 mt-1">Update your account password below.</p>
          </div>

          <form onSubmit={handleSubmit} noValidate>
            <InputField
              label="Current Password"
              id="currentPassword"
              type="password"
              placeholder="Enter current password"
              value={form.currentPassword}
              onChange={(e) => setField("currentPassword", e.target.value)}
              error={errors.currentPassword}
            />
            <InputField
              label="New Password"
              id="newPassword"
              type="password"
              placeholder="Enter new password"
              value={form.newPassword}
              onChange={(e) => setField("newPassword", e.target.value)}
              error={errors.newPassword}
            />
            <InputField
              label="Confirm New Password"
              id="confirmPassword"
              type="password"
              placeholder="Confirm new password"
              value={form.confirmPassword}
              onChange={(e) => setField("confirmPassword", e.target.value)}
              error={errors.confirmPassword}
            />

            <div className="flex gap-3 mt-2">
              <button
                type="button"
                onClick={() => router.back()}
                className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-semibold rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-70 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center"
              >
                {isLoading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                ) : "Change Password"}
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}
