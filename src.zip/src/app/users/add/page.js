"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/common/header";
import InputField from "@/components/common/inputFields";
import { toast } from "@/lib/toast";
import { signupUser, fetchCompanies, fetchGroups } from "@/app/lib/api";

function getUser() {
  if (typeof window === "undefined") return null;
  const stored = localStorage.getItem("pp_user") || sessionStorage.getItem("pp_user");
  return stored ? JSON.parse(stored) : null;
}

function isSuperAdminUser(user) {
  return (
    user?.role === "superAdmin" ||
    user?.isSuperAdmin === true ||
    user?.email === "omifarakate@gmail.com"
  );
}

const INITIAL_FORM = {
  firstName: "",
  lastName: "",
  userName: "",
  email: "",
  password: "",
  confirmPassword: "",
  dialCode: "",
  phoneNumber: "",
  birthDate: "",
  profImg: null,
  companyId: "",
  groupId: "",
};

export default function AddUserPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState(null);
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [companies, setCompanies] = useState([]);
  const [groups, setGroups] = useState([]);
  const [dropdownLoading, setDropdownLoading] = useState(true);

  useEffect(() => {
    const u = getUser();
    if (!u) { router.replace("/login"); return; }
    if (!isSuperAdminUser(u)) { router.replace("/users"); return; }
    setCurrentUser(u);
  }, [router]);

  useEffect(() => {
    setDropdownLoading(true);
    Promise.all([fetchCompanies(), fetchGroups()])
      .then(([comp, grp]) => {
        setCompanies(comp);
        setGroups(grp);
      })
      .catch((err) => toast.error("Failed to load options: " + err.message))
      .finally(() => setDropdownLoading(false));
  }, []);

  const setField = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const validate = () => {
    const e = {};
    if (!form.firstName.trim()) e.firstName = "First name is required";
    if (!form.lastName.trim()) e.lastName = "Last name is required";
    if (!form.userName.trim()) e.userName = "Username is required";
    if (!form.email.trim()) e.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = "Enter a valid email";
    if (!form.password) e.password = "Password is required";
    else if (form.password.length < 6) e.password = "Password must be at least 6 characters";
    if (form.password !== form.confirmPassword) e.confirmPassword = "Passwords do not match";
    if (!form.birthDate) e.birthDate = "Date of birth is required";
    else if (form.birthDate) {
      const birthDate = new Date(form.birthDate);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      if (age < 18) e.birthDate = "User must be at least 18 years old";
    }
    if (!form.companyId) e.companyId = "Please select a company";
    if (!form.groupId) e.groupId = "Please select a group";
    return e;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }
    setIsLoading(true);
    try {
      const response = await signupUser({
        firstName: form.firstName,
        lastName: form.lastName,
        userName: form.userName,
        email: form.email,
        password: form.password,
        dialCode: form.dialCode || "",
        phoneNumber: form.phoneNumber || "",
        birthDate: form.birthDate,
        profImg: form.profImg || undefined,
        companyId: Number(form.companyId),
        groupId: Number(form.groupId),
      });
      
      // Verify success from response
      const settings = response?.settings || response;
      if (settings?.success === 1 || settings?.success === "1") {
        toast.success("User added successfully!");
        window.dispatchEvent(new CustomEvent("pp:refresh"));
        setTimeout(() => router.push("/users"), 700);
      } else {
        const errorMsg = settings?.message || "User creation failed";
        if (errorMsg.toLowerCase().includes("duplicate") || errorMsg.toLowerCase().includes("already exists")) {
          toast.error("Email or username already exists");
          if (errorMsg.toLowerCase().includes("email")) {
            setErrors({ email: "Email already in use" });
          } else if (errorMsg.toLowerCase().includes("username") || errorMsg.toLowerCase().includes("username")) {
            setErrors({ userName: "Username already in use" });
          }
        } else {
          toast.error(errorMsg);
        }
      }
    } catch (err) {
      const errorMsg = err.message || "Failed to add user";
      if (errorMsg.toLowerCase().includes("duplicate") || errorMsg.toLowerCase().includes("already exists")) {
        toast.error("Email or username already exists");
      } else {
        toast.error(errorMsg);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("pp_user");
    sessionStorage.removeItem("pp_user");
    toast.success("Logged out");
    router.replace("/login");
  };

  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-[#f7f8fa] flex flex-col">
      <Header user={currentUser} onLogout={handleLogout} />
      <main className="flex-1 px-4 sm:px-6 py-5 mx-auto">
        <div className="flex items-center gap-1.5 text-sm text-gray-400 mb-4">
          <span className="hover:text-blue-500 cursor-pointer" onClick={() => router.push("/users")}>Users</span>
          <span>›</span>
          <span className="text-gray-600 font-medium">Add User</span>
        </div>

        <div className="flex items-center justify-between mb-5">
          <h1 className="text-xl font-bold text-gray-800">Add New User</h1>
          <button
            onClick={() => router.push("/users")}
            className="flex items-center gap-1.5 text-sm text-gray-600 hover:text-gray-900 border border-gray-200 bg-white rounded-lg px-3 py-1.5 hover:bg-gray-50 transition-colors"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="15 18 9 12 15 6" />
            </svg>
            Back
          </button>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
          <form onSubmit={handleSubmit} noValidate>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
              <InputField
                label="First Name"
                id="firstName"
                placeholder="First name"
                value={form.firstName}
                onChange={(e) => setField("firstName", e.target.value)}
                error={errors.firstName}
              />
              <InputField
                label="Last Name"
                id="lastName"
                placeholder="Last name"
                value={form.lastName}
                onChange={(e) => setField("lastName", e.target.value)}
                error={errors.lastName}
              />
            </div>
            <InputField
              label="Username"
              id="userName"
              placeholder="username"
              value={form.userName}
              onChange={(e) => setField("userName", e.target.value)}
              error={errors.userName}
            />
            <InputField
              label="Email"
              id="email"
              type="email"
              placeholder="you@company.com"
              value={form.email}
              onChange={(e) => setField("email", e.target.value)}
              error={errors.email}
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
              <InputField
                label="Password"
                id="password"
                type="password"
                placeholder="Password"
                value={form.password}
                onChange={(e) => setField("password", e.target.value)}
                error={errors.password}
              />
              <InputField
                label="Confirm Password"
                id="confirmPassword"
                type="password"
                placeholder="Confirm password"
                value={form.confirmPassword}
                onChange={(e) => setField("confirmPassword", e.target.value)}
                error={errors.confirmPassword}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-x-4">
              <InputField
                label="Dial Code"
                id="dialCode"
                placeholder="+1"
                value={form.dialCode}
                onChange={(e) => setField("dialCode", e.target.value)}
                error={errors.dialCode}
              />
              <div className="sm:col-span-2">
                <InputField
                  label="Phone Number"
                  id="phoneNumber"
                  placeholder="1234567890"
                  value={form.phoneNumber}
                  onChange={(e) => setField("phoneNumber", e.target.value)}
                  error={errors.phoneNumber}
                />
              </div>
            </div>
            <InputField
              label="Date of Birth"
              id="birthDate"
              type="date"
              value={form.birthDate}
              onChange={(e) => setField("birthDate", e.target.value)}
              error={errors.birthDate}
            />
            <div className="flex flex-col gap-1 mb-4">
              <label htmlFor="profImg" className="text-[13px] font-medium text-gray-800">
                Profile Image
              </label>
              <input
                type="file"
                id="profImg"
                accept="image/*"
                onChange={(e) => setField("profImg", e.target.files?.[0] || null)}
                className="bg-gray-100 rounded-md border-[1.5px] border-transparent focus:border-blue-500 px-3.5 py-[10px] text-sm text-gray-900 outline-none file:mr-3 file:py-1 file:px-2 file:bg-blue-100 file:text-blue-600 file:border-0 file:rounded file:cursor-pointer"
              />
              {form.profImg && (
                <p className="text-xs text-gray-500">
                  Selected: {form.profImg.name} ({(form.profImg.size / 1024).toFixed(2)} KB)
                </p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
              <div className="flex flex-col gap-1 mb-4">
                <label htmlFor="companyId" className="text-[13px] font-medium text-gray-800">
                  Company<em className="text-red-500 text-xs">*</em>
                </label>
                <select
                  id="companyId"
                  value={form.companyId}
                  onChange={(e) => setField("companyId", e.target.value)}
                  disabled={dropdownLoading}
                  className="bg-gray-100 rounded-md border-[1.5px] border-transparent focus:border-blue-500 px-3.5 py-[10px] text-sm text-gray-900 outline-none"
                >
                  <option value="">{dropdownLoading ? "Loading…" : "Select company"}</option>
                  {companies.map((c) => (
                    <option key={c.id} value={c.id}>{c.companyName}</option>
                  ))}
                </select>
                {errors.companyId && <p className="text-red-500 text-xs">{errors.companyId}</p>}
              </div>
              <div className="flex flex-col gap-1 mb-4">
                <label htmlFor="groupId" className="text-[13px] font-medium text-gray-800">
                  Group / Role<em className="text-red-500 text-xs">*</em>
                </label>
                <select
                  id="groupId"
                  value={form.groupId}
                  onChange={(e) => setField("groupId", e.target.value)}
                  disabled={dropdownLoading}
                  className="bg-gray-100 rounded-md border-[1.5px] border-transparent focus:border-blue-500 px-3.5 py-[10px] text-sm text-gray-900 outline-none"
                >
                  <option value="">{dropdownLoading ? "Loading…" : "Select group"}</option>
                  {groups.map((g) => (
                    <option key={g.id} value={g.id}>{g.groupName}</option>
                  ))}
                </select>
                {errors.groupId && <p className="text-red-500 text-xs">{errors.groupId}</p>}
              </div>
            </div>

            <div className="flex gap-3 mt-2">
              <button
                type="button"
                onClick={() => router.push("/users")}
                className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-semibold rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-70 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
                    </svg>
                    Add User
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}
