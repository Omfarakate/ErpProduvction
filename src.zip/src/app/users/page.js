"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { isSuperAdminUser, getStoredUser, clearStoredUser } from "@/lib/auth";
import UserGridView from "@/components/users/UserGridView";
import UserListView from "@/components/users/UserListView";
import UserTableView from "@/components/users/UserTableView";
import Pagination from "@/components/common/pagination";
import Header from "@/components/common/header";
import { CallApi } from "@/lib/general";
import LoadingSkeleton from "@/components/users/loadingState";
import EmptyState from "@/components/users/emptyState";
import { toast } from "@/lib/toast";

const VIEW_KEY = "users_view_preference";
const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

function getUser() {
  return getStoredUser();
}

export default function UsersPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [activeFilters, setActiveFilters] = useState({}); 
  const [view, setView] = useState("table");
  const [limit, setLimit] = useState(10);

  useEffect(() => {
    const u = getUser();
    if (!u) {
      router.replace("/login");
      return;
    }

    setUser(u);
    const saved = localStorage.getItem(VIEW_KEY);
    if (saved) setView(saved);
  }, [router]);

  const fetchUsers = useCallback(async (pageNum, filters) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        limit: limit.toString(),
        page: pageNum.toString(),
      });

      if (filters?.search) {
        params.set("search", filters.search);
      }

      if (filters?.name) params.set("search", filters.name);
      if (filters?.email) params.set("email", filters.email);
      if (filters?.status) params.set("status", filters.status);
      if (filters?.groupName) params.set("group", filters.groupName);
      if (filters?.companyName) params.set("company", filters.companyName);

      if (Array.isArray(filters?.filters)) {
        const fieldMap = {
          "Name": "search",
          "Email": "email",
          "Phone Number": "phone_number",
          "User Name": "user_name",
          "Group Name": "group",
        };
        filters.filters.forEach((f) => {
          const paramKey = fieldMap[f.field] || f.field.toLowerCase().replace(/ /g, "_");
          if (f.value) params.set(paramKey, f.value);
        });
      }

      const url = `${BASE_URL}/user/users-list?${params.toString()}`;
      const response = await CallApi(url, { relay: true });

      const res = response?.settings || response;
      if (res?.success === 1 || res?.success === true) {
        setUsers(res.data?.list || []);
        setTotalPages(res.data?.pagination?.total_pages || 1);
        setTotalCount(res.data?.pagination?.total || 0);
      } else {
        setUsers([]);
        setTotalPages(1);
        setTotalCount(0);
      }
    } catch (error) {
      console.error("fetchUsers Error:", error);
      setUsers([]);
    } finally {
      setLoading(false);
    }
  }, [limit]);

  useEffect(() => {
    const handler = () => fetchUsers(page, activeFilters);
    window.addEventListener("pp:refresh", handler);
    return () => window.removeEventListener("pp:refresh", handler);
  }, [page, activeFilters, fetchUsers]);

  useEffect(() => {
    if (user) {
      fetchUsers(page, activeFilters);
    }
  }, [user, page, activeFilters, fetchUsers]);

  const handleViewChange = (v) => {
    setView(v);
    localStorage.setItem(VIEW_KEY, v);
  };

  const handleLogout = () => {
    clearStoredUser();
    toast.success("Logged out successfully");
    router.replace("/login");
  };

  const handleSearch = (val) => {
    if (typeof val === "string") {
      setActiveFilters({ search: val });
    } else {
      setActiveFilters(val);
    }
    setPage(1); 
  };

  const handleRefresh = () => {
    fetchUsers(page, activeFilters);
  };

  const handlePageSizeChange = (newLimit) => {
    setLimit(newLimit);
    setPage(1);
  };

  if (!user) return null;

  const isSuperAdmin = isSuperAdminUser(user);

  const searchFields = ["Name", "Email", "Phone Number", "User Name", "Group Name"];

  return (
    <div className="min-h-screen bg-[#f7f8fa] flex flex-col">
      <Header
        user={user}
        onLogout={handleLogout}
        onSearch={handleSearch}
        onRefresh={handleRefresh}
        searchFields={searchFields}
      />

      <main className="flex-1 px-4 sm:px-6 py-5 w-full mx-auto">
        {/* Breadcrumb */}
        <div className="flex items-center gap-1.5 text-sm text-gray-400 mb-4">
          <span
            className="hover:text-blue-500 cursor-pointer"
            onClick={() => router.push("/dashboard")}
          >
            DashBoard
          </span>
          <span>›</span>
          <span className="text-gray-600 font-medium">Users</span>
        </div>

        {/* Page header */}
        <div className="flex flex-wrap items-center gap-3 mb-5">
          <h1 className="text-lg font-bold text-gray-800">Listing</h1>
          <div className="flex-1" />

          {/* Active filter indicator */}
          {Object.values(activeFilters).some((v) =>
            typeof v === "string" ? v : Array.isArray(v) ? v.length > 0 : false
          ) && (
            <button
              onClick={() => { setActiveFilters({}); setPage(1); }}
              className="text-xs text-blue-600 border border-blue-200 px-2 py-1 rounded-lg hover:bg-blue-50 flex items-center gap-1"
            >
              <span>Clear filters</span>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          )}

          {/* View toggle */}
          <div className="flex items-center bg-white border border-gray-200 rounded-lg p-1 gap-0.5">
            {[
              {
                key: "grid", title: "Grid",
                icon: (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <rect x="3" y="3" width="7" height="7" rx="1" />
                    <rect x="14" y="3" width="7" height="7" rx="1" />
                    <rect x="3" y="14" width="7" height="7" rx="1" />
                    <rect x="14" y="14" width="7" height="7" rx="1" />
                  </svg>
                ),
              },
              {
                key: "list", title: "List",
                icon: (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <line x1="4" y1="6" x2="20" y2="6" />
                    <line x1="4" y1="12" x2="20" y2="12" />
                    <line x1="4" y1="18" x2="20" y2="18" />
                  </svg>
                ),
              },
              {
                key: "table", title: "Table",
                icon: (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="3" width="18" height="18" rx="2" />
                    <line x1="3" y1="9" x2="21" y2="9" />
                    <line x1="3" y1="15" x2="21" y2="15" />
                    <line x1="9" y1="9" x2="9" y2="21" />
                  </svg>
                ),
              },
            ].map(({ key, title, icon }) => (
              <button
                key={key}
                onClick={() => handleViewChange(key)}
                title={title}
                className={`p-1.5 rounded-md transition-colors ${
                  view === key ? "bg-blue-100 text-blue-600" : "text-gray-400 hover:text-gray-600"
                }`}
              >
                {icon}
              </button>
            ))}
          </div>

          {isSuperAdmin && (
            <button
              onClick={() => router.push("/users/add")}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors shadow-sm"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
              Add User
            </button>
          )}
        </div>

        {/* Content */}
        {loading ? (
          <LoadingSkeleton view={view} />
        ) : users.length === 0 ? (
          <EmptyState />
        ) : (
          <>
            {view === "grid" && <UserGridView users={users} isSuperAdmin={isSuperAdmin} />}
            {view === "list" && <UserListView users={users} isSuperAdmin={isSuperAdmin} />}
            {view === "table" && <UserTableView users={users} isSuperAdmin={isSuperAdmin} />}

            <div className="flex items-center justify-between mt-5">
              <span className="text-sm text-gray-500">
                View {(page - 1) * limit + 1}–{Math.min(page * limit, totalCount)} of {totalCount}
              </span>
              <Pagination
                page={page}
                totalPages={totalPages}
                pageSize={limit}
                onPageChange={setPage}
                onPageSizeChange={handlePageSizeChange}
              />
            </div>
          </>
        )}
      </main>
    </div>
  );
}
