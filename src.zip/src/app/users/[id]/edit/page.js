"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter, useParams } from "next/navigation";
import Header from "@/components/common/header";
import InputField from "@/components/common/inputFields";
import { toast } from "@/lib/toast";
import { CallApi } from "@/lib/general";
import { parseApiError } from "@/lib/errorHandler";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

function getUser() {
  if (typeof window === "undefined") return null;
  const stored = localStorage.getItem("pp_user") || sessionStorage.getItem("pp_user");
  return stored ? JSON.parse(stored) : null;
}

function isSuperAdminUser(user) {
  return (
    user?.role === "superAdmin" ||
    user?.isSuperAdmin === true ||
    user?.email === "omifarakate@gmail.com"
  );
}

export default function EditUserPage() {
  const router = useRouter();
  const params = useParams();
  const id = params?.id;

  const [currentUser, setCurrentUser] = useState(null);
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    userName: "",
    email: "",
    dialCode: "",
    phoneNumber: "",
    birthDate: "",
    profImg: null,
    isActive: "Active",
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(true);
  const [fetchError, setFetchError] = useState(null);

  useEffect(() => {
    const u = getUser();
    if (!u) { router.replace("/login"); return; }
    if (!isSuperAdminUser(u)) { router.replace("/users"); return; }
    setCurrentUser(u);
  }, [router]);

  const fetchUser = useCallback(async () => {
    if (!id) return;
    setIsFetching(true);
    setFetchError(null);
    try {
      const res = await fetch(`/relayApi?path=${btoa(`${BASE_URL}/user/user/${id}`)}`);
      const json = await res.json();
      if (json?.settings?.success === 1 && json.settings.data) {
        const u = json.settings.data;
        setForm({
          firstName: u.firstName || "",
          lastName: u.lastName || "",
          userName: u.userName || "",
          email: u.email || "",
          dialCode: u.dialCode || "",
          phoneNumber: u.phoneNumber || "",
          birthDate: u.birthDate ? u.birthDate.substring(0, 10) : "",
          profImg: null,
          isActive: u.isActive || "Active",
        });
      } else {
        setFetchError(json?.settings?.message || "User not found");
      }
    } catch (e) {
      setFetchError(e.message || "Failed to load user");
    } finally {
      setIsFetching(false);
    }
  }, [id]);

  useEffect(() => {
    if (currentUser) fetchUser();
  }, [currentUser, fetchUser]);

  const setField = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };

  const validate = () => {
    const e = {};
    if (!form.firstName.trim()) e.firstName = "Please enter first name";
    if (!form.lastName.trim()) e.lastName = "Please enter last name";
    if (!form.userName.trim()) e.userName = "Please enter username";
    if (!form.email.trim()) e.email = "Please enter email";
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = "Enter a valid email";
    if (form.birthDate) {
      const birthDate = new Date(form.birthDate);
      console.log("Validating birth date:",birthDate);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      if (age < 18) e.birthDate = "User must be at least 18 years old";
    }
    return e;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      toast.error("Please fix the form errors");
      return;
    }
    setIsLoading(true);
    try {
      const formData = new FormData();
      formData.append("firstName", form.firstName);
      formData.append("lastName", form.lastName);
      formData.append("userName", form.userName);
      formData.append("email", form.email);
      formData.append("dialCode", form.dialCode);
      formData.append("phoneNumber", form.phoneNumber);
      formData.append("birthDate", form.birthDate || "");
      formData.append("isActive", form.isActive);
      formData.append("updatedDate", new Date().toISOString());
      
      if (form.profImg) {
        formData.append("profImg", form.profImg);
      }

      const url = `${BASE_URL}/user/user-update/${id}`;
      const res = await fetch(url, {
        method: "PUT",
        body: formData,
      });

      if (!res.ok) {
        throw new Error("Failed to update user");
      }

      const result = await res.json();
      const response = result?.settings || result;
      
      if (response?.success === 1 || response?.success === true) {
        toast.success("User updated successfully!");
        setTimeout(() => router.push(`/users/${id}`), 700);
      } else {
        const msg = parseApiError(response?.message || response || "Failed to update user");
        toast.error(msg);
      }
    } catch (err) {
      const msg = parseApiError(err);
      toast.error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("pp_user");
    sessionStorage.removeItem("pp_user");
    toast.success("Logged out");
    router.replace("/login");
  };

  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-[#f7f8fa] flex flex-col">
      <Header user={currentUser} onLogout={handleLogout} />
      <main className="flex-1 px-4 sm:px-6 py-5 mx-auto">
          {/* Breadcrumb */}
        <div className="flex items-center gap-1.5 text-sm text-gray-400 mb-4">
          <span className="hover:text-blue-500 cursor-pointer" onClick={() => router.push("/users")}>Users</span>
          <span>›</span>
          <span className="hover:text-blue-500 cursor-pointer" onClick={() => router.push(`/users/${id}`)}>Details</span>
          <span>›</span>
          <span className="text-gray-600 font-medium">Edit</span>
        </div>

        <div className="flex items-center justify-between mb-5">
          <h1 className="text-xl font-bold text-gray-800">Edit User</h1>
          <button
            onClick={() => router.push(`/users/${id}`)}
            className="flex items-center gap-1.5 text-sm text-gray-600 hover:text-gray-900 border border-gray-200 bg-white rounded-lg px-3 py-1.5 hover:bg-gray-50 transition-colors"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="15 18 9 12 15 6" />
            </svg>
            Back
          </button>
        </div>

        {isFetching ? (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
            <div className="space-y-4 animate-pulse">
              {[1, 2, 3, 4].map((i) => (
                <div key={i}>
                  <div className="h-3 bg-gray-100 rounded w-24 mb-2" />
                  <div className="h-10 bg-gray-100 rounded" />
                </div>
              ))}
            </div>
          </div>
        ) : fetchError ? (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8 text-center">
            <p className="text-red-500 mb-4">{fetchError}</p>
            <button onClick={fetchUser} className="text-sm text-blue-600 border border-blue-200 px-4 py-2 rounded-lg hover:bg-blue-50">
              Retry
            </button>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
            <form onSubmit={handleSubmit} noValidate>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
                <InputField
                  label="First Name"
                  id="firstName"
                  placeholder="First name"
                  value={form.firstName}
                  onChange={(e) => setField("firstName", e.target.value)}
                  error={errors.firstName}
                />
                <InputField
                  label="Last Name"
                  id="lastName"
                  placeholder="Last name"
                  value={form.lastName}
                  onChange={(e) => setField("lastName", e.target.value)}
                  error={errors.lastName}
                />
              </div>
              <InputField
                label="Username"
                id="userName"
                placeholder="username"
                value={form.userName}
                onChange={(e) => setField("userName", e.target.value)}
                error={errors.userName}
              />
              <InputField
                label="Email"
                id="email"
                type="email"
                placeholder="you@company.com"
                value={form.email}
                onChange={(e) => setField("email", e.target.value)}
                error={errors.email}
              />
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-x-4">
                <InputField
                  label="Dial Code"
                  id="dialCode"
                  placeholder="+1"
                  value={form.dialCode}
                  onChange={(e) => setField("dialCode", e.target.value)}
                  error={errors.dialCode}
                />
                <div className="sm:col-span-2">
                  <InputField
                    label="Phone Number"
                    id="phoneNumber"
                    placeholder="1234567890"
                    value={form.phoneNumber}
                    onChange={(e) => setField("phoneNumber", e.target.value)}
                    error={errors.phoneNumber}
                  />
                </div>
              </div>
              <InputField
                label="Date of Birth"
                id="birthDate"
                type="date"
                value={form.birthDate}
                onChange={(e) => setField("birthDate", e.target.value)}
                error={errors.birthDate}
              />
                 {/* <InputField
                              label="Date of Birth"
                              id="birthDate"
                              type="date"
                              value={form.birthDate}
                              onChange={set("birthDate")}
                              error={errors.birthDate}
                              required
                            /> */}
              <div className="flex flex-col gap-1 mb-4">
                <label htmlFor="profImg" className="text-[13px] font-medium text-gray-800">
                  Profile Image
                </label>
                <input
                  type="file"
                  id="profImg"
                  accept="image/*"
                  onChange={(e) => setField("profImg", e.target.files?.[0] || null)}
                  className="bg-gray-100 rounded-md border-[1.5px] border-transparent focus:border-blue-500 px-3.5 py-[10px] text-sm text-gray-900 outline-none file:mr-3 file:py-1 file:px-2 file:bg-blue-100 file:text-blue-600 file:border-0 file:rounded file:cursor-pointer"
                />
                {form.profImg && (
                  <p className="text-xs text-gray-500">
                    Selected: {form.profImg.name} ({(form.profImg.size / 1024).toFixed(2)} KB)
                  </p>
                )}
              </div>

              <div className="flex flex-col gap-1 mb-4">
                <label htmlFor="isActive" className="text-[13px] font-medium text-gray-800">
                  Status
                </label>
                <select
                  id="isActive"
                  value={form.isActive}
                  onChange={(e) => setField("isActive", e.target.value)}
                  className="bg-gray-100 rounded-md border-[1.5px] border-transparent focus:border-blue-500 px-3.5 py-[10px] text-sm text-gray-900 outline-none"
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>

              <div className="flex gap-3 mt-4">
                <button
                  type="button"
                  onClick={() => router.push(`/users/${id}`)}
                  className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-semibold rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-70 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <span className="inline-block w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                      Save Changes
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}
