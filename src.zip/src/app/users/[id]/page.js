"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter, useParams } from "next/navigation";
import { isSuperAdminUser, getStoredUser } from "@/lib/auth";
import Header from "@/components/common/header";
import { toast } from "@/lib/toast";
import { CallApi } from "@/lib/general";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

function getUser() {
  return getStoredUser();
}

function getImageUrl(profImg, userId) {
  if (!profImg) return "https://kommodo.ai/i/JeEUjzrLM3c9N2lpsXMa";
  if (profImg.startsWith("http")) return profImg;  
  if (userId) {
    const filename = profImg.split('/').pop();
    // console.log(" image URL with userId:", `${BASE_URL}/uploads/profileImg/${userId}/${filename}`);
    return `${BASE_URL}/uploads/profileImg/${userId}/${filename}`;
  }
  else return "https://kommodo.ai/i/JeEUjzrLM3c9N2lpsXMa"
  return `${BASE_URL}/uploads/${profImg}`;
}

export default function UserDetailPage() {
  const router = useRouter();
  const params = useParams();
  const id = params?.id;

  const [currentUser, setCurrentUser] = useState(null);
  const [detailUser, setDetailUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("summary");
  const [imgError, setImgError] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);

  useEffect(() => {
    const u = getUser();
    if (!u) { router.replace("/login"); return; }
    setCurrentUser(u);
  }, [router]);

  const fetchUserDetail = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    setImgError(false);
    try {
      const res = await fetch(`/relayApi?path=${btoa(`${BASE_URL}/user/user/${id}`)}`);
      const json = await res.json();
      if (json?.settings?.success === 1 && json.settings.data) {
        setDetailUser(json.settings.data);
      } else {
        setError(json?.settings?.message || json?.message || "User not found");
      }
    } catch (e) {
      setError(e.message || "Failed to load user");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    if (currentUser) fetchUserDetail();
  }, [currentUser, fetchUserDetail]);

  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      const url = `${BASE_URL}/user/user-update/${id}`;
      const formData = new FormData();
      formData.append("isActive", "Inactive");
      formData.append("updatedDate", new Date().toISOString());
      
      const res = await fetch(url, {
        method: "PUT",
        body: formData,
      });
      
      if (!res.ok) {
        throw new Error("Failed to deactivate user");
      }

      const result = await res.json();
      const response = result?.settings || result;
      
      if (response?.success === 1 || response?.success === true) {
        toast.success("User deactivated successfully");
        setShowDeleteModal(false);
        router.push("/users");
      } else {
        toast.error(response?.message || "Failed to deactivate user");
        setShowDeleteModal(false);
      }
    } catch (err) {
      toast.error(err.message || "Failed to deactivate user");
      setShowDeleteModal(false);
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("pp_user");
    sessionStorage.removeItem("pp_user");
    toast.success("Logged out");
    router.replace("/login");
  };

  if (!currentUser) return null;

  const isAdmin = isSuperAdminUser(currentUser);
  const fullName = detailUser
    ? [detailUser.firstName, detailUser.lastName].filter(Boolean).join(" ") || detailUser.userName || "—"
    : "—";
  const isActive = detailUser?.isActive === "Active";
  const groupName = detailUser?.userGroupCompanies?.[0]?.group?.groupName || "—";
  const companyName = detailUser?.userGroupCompanies?.[0]?.company?.companyName || "—";
  const imgUrl = detailUser ? getImageUrl(detailUser.profImg, detailUser.id) : null;

  return (
    <div className="min-h-screen bg-[#f4f5f7] flex flex-col">
      <Header user={currentUser} onLogout={handleLogout} />

      <main className="flex-1 px-4 sm:px-6 py-5 w-full mx-auto max-w-full">
        <div className="flex items-center gap-1.5 text-sm text-gray-400 mb-4">
          <span className="hover:text-blue-500 cursor-pointer" onClick={() => router.push("/users")}>Users</span>
          <span>›</span>
          <span className="text-gray-600 font-medium">Details</span>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <h1 className="text-xl font-bold text-gray-800">Details</h1>
          <div className="flex items-center gap-2">
            <button
              onClick={() => router.push("/users")}
              className="flex items-center gap-1.5 text-sm text-gray-600 hover:text-gray-900 border border-gray-200 bg-white rounded-lg px-3 py-1.5 hover:bg-gray-50 transition-colors"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="15 18 9 12 15 6" />
              </svg>
              Back
            </button>
            {isAdmin && detailUser && (
              <>
                <button
                  onClick={() => router.push(`/users/${id}/edit`)}
                  className="flex items-center gap-1.5 text-sm text-white bg-blue-600 hover:bg-blue-700 rounded-lg px-3 py-1.5 transition-colors"
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                  </svg>
                  Edit
                </button>
                <button
                  onClick={() => setShowDeleteModal(true)}
                  className="flex items-center gap-1.5 text-sm text-white bg-amber-500 hover:bg-amber-600 rounded-lg px-3 py-1.5 transition-colors"
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="12" y1="8" x2="12" y2="12" />
                    <line x1="12" y1="16" x2="12.01" y2="16" />
                  </svg>
                  Deactivate
                </button>
              </>
            )}
          </div>
        </div>

        {loading ? (
          <DetailSkeleton />
        ) : error ? (
          <ErrorState error={error} onRetry={fetchUserDetail} />
        ) : detailUser ? (
          <div className="grid grid-cols-1 xl:grid-cols-[280px_1.8fr_1fr_1fr] gap-4">
            {/* Left sidebar */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 flex flex-col gap-4">
              <div>
                <h2 className="font-bold text-gray-800 text-base">{fullName}</h2>
                <p className={`text-sm mt-0.5 font-medium ${isActive ? "text-green-500" : "text-gray-400"}`}>
                  {isActive ? "Active" : "Inactive"}
                </p>
              </div>
              <div className="h-px bg-gray-100" />
              <nav className="flex flex-col gap-1">
                <SidebarTab label="Summary" active={activeTab === "summary"} onClick={() => setActiveTab("summary")} />
                <SidebarTab label="Other Profiles" active={activeTab === "profiles"} onClick={() => setActiveTab("profiles")} />
              </nav>
              <div className="h-px bg-gray-100" />
              <div className="flex flex-col gap-2">
                <CountBadge label="Notes" count={0} />
                <CountBadge label="Activities" count={0} />
              </div>
            </div>

            {/* Profile card */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
              <div className="flex items-center gap-4 mb-5 pb-5 border-b border-gray-100">
                {imgUrl && !imgError ? (
                  <img
                    src={imgUrl}
                    alt={fullName}
                    className="w-16 h-16 rounded-full object-cover border-2 border-gray-100 flex-shrink-0"
                    onError={() => setImgError(true)}
                  />
                ) : (
                  <AvatarFallback name={fullName} size={64} />
                )}
                <div>
                  <h3 className="font-bold text-gray-900 text-base">{fullName}</h3>
                  <span className={`inline-block mt-1 px-2.5 py-0.5 rounded text-xs font-semibold ${isActive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-500"}`}>
                    {isActive ? "Active" : "Inactive"}
                  </span>
                </div>
              </div>
              <div className="flex flex-col gap-3">
                <DetailRow label="User Name" value={detailUser.userName || detailUser.email} />
                <DetailRow label="Date of Birth" value={detailUser.birthDate ? new Date(detailUser.birthDate).toLocaleDateString("en-GB") : "-"} />
                <DetailRow label="Group" value={groupName} />
                <DetailRow label="Company" value={companyName} isLink />
                <DetailRow
                  label="Added Date"
                  value={detailUser.addedDate ? new Date(detailUser.addedDate).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "-"}
                />
                <DetailRow
                  label="Modified Date"
                  value={detailUser.updatedDate ? new Date(detailUser.updatedDate).toLocaleString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "-"}
                />
                <DetailRow label="Is Email Verified" value={detailUser.isEmailVerified ? "Yes" : "No"} />
                <DetailRow label="Preferred Language" value={detailUser.preferredLanguage || detailUser.language || "-"} />
              </div>
            </div>

            {/* Contact Info */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
              <h4 className="font-semibold text-gray-700 text-sm mb-4">Contact Info</h4>
              <div className="flex flex-col gap-3">
                <ContactRow label="Email" value={detailUser.email} />
                <ContactRow label="Phone Number" value={detailUser.phoneNumber || "-"} />
                <ContactRow label="Alternate Phone Number" value={detailUser.alternatePhoneNumber || detailUser.alternatePhone || "-"} />
              </div>
            </div>

            {/* Third Party Settings */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
              <h4 className="font-semibold text-gray-700 text-sm mb-4">Third Party Settings</h4>
              <div className="flex flex-col gap-4">
                <ThirdPartyRow label="Central User Code" value={detailUser.centralUserCode || "-"} />
                <ThirdPartyRow label="Account Uuid" value={detailUser.accountUuid || `${detailUser.id}-account-uuid`} truncate />
                <ThirdPartyRow label="Project Uuid" value={detailUser.projectUuid || `${detailUser.id}-project-uuid`} truncate />
              </div>
            </div>

            {/* Remarks */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 xl:col-start-3 xl:col-span-2">
              <h4 className="font-semibold text-gray-700 text-sm mb-4">Remarks</h4>
              {detailUser.remarks ? (
                <p className="text-sm text-gray-600">{detailUser.remarks}</p>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <p className="text-sm text-gray-400">No remarks found.</p>
                </div>
              )}
            </div>
          </div>
        ) : null}
      </main>

      {/* Deactivate confirmation modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.4)" }}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-[400px] p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="8" x2="12" y2="12" />
                  <line x1="12" y1="16" x2="12.01" y2="16" />
                </svg>
              </div>
              <div>
                <h3 className="text-base font-bold text-gray-900">Deactivate User</h3>
                <p className="text-sm text-gray-500">User account will be marked as inactive.</p>
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-6">
              Are you sure you want to deactivate <strong>{fullName}</strong>? The user will no longer be able to access the system.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteModal(false)}
                disabled={deleteLoading}
                className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-semibold rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={deleteLoading}
                className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-70 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center"
              >
                {deleteLoading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                ) : "Deactivate"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SidebarTab({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`text-left px-3 py-2 rounded-lg text-sm font-medium transition-colors ${active ? "bg-blue-600 text-white" : "text-gray-600 hover:bg-gray-50"}`}
    >
      {label}
    </button>
  );
}

function CountBadge({ label, count }) {
  return (
    <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-gray-50">
      <span className="text-sm text-gray-600">{label}</span>
      <span className="text-sm font-bold text-gray-700 bg-white px-2 py-0.5 rounded-md border border-gray-100">{count}</span>
    </div>
  );
}

function DetailRow({ label, value, isLink }) {
  return (
    <div className="flex items-start justify-between gap-4 text-sm">
      <span className="text-gray-400 flex-shrink-0 min-w-[130px]">{label}</span>
      <span className={`text-right font-medium break-all ${isLink ? "text-blue-600" : "text-gray-800"}`}>{value || "-"}</span>
    </div>
  );
}

function ContactRow({ label, value }) {
  return (
    <div className="flex items-start justify-between gap-4 text-sm">
      <span className="text-gray-400 flex-shrink-0 min-w-[120px]">{label}</span>
      <span className="text-gray-800 font-medium text-right break-all">{value || "-"}</span>
    </div>
  );
}

function ThirdPartyRow({ label, value, truncate }) {
  return (
    <div className="text-sm">
      <span className="text-gray-400 block mb-0.5">{label}</span>
      <span className={`text-gray-800 font-medium ${truncate ? "block truncate" :""}`} title={value}>{value || "-"}</span>
    </div>
  );
}

function AvatarFallback({ name, size }) {
  const colors = ["#2563eb", "#7c3aed", "#059669", "#dc2626", "#d97706", "#0891b2"];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  const color = colors[Math.abs(hash) % colors.length];
  const initials = name.split(" ").filter(Boolean).map((w) => w[0]).join("").substring(0, 2).toUpperCase();
  return (
    <div
      className="rounded-full flex items-center justify-center font-bold text-white flex-shrink-0"
      style={{ width: size, height: size, background: color, fontSize: size * 0.35 }}
    >
      {initials || "?"}
    </div>
  );
}

function DetailSkeleton() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr_1fr_1fr] gap-4">
      {[0, 1, 2, 3].map((i) => (
        <div key={i} className="bg-white rounded-xl border border-gray-100 p-5 h-64 animate-pulse">
          <div className="h-4 bg-gray-100 rounded w-3/4 mb-3" />
          <div className="h-3 bg-gray-100 rounded w-1/2 mb-6" />
          <div className="space-y-3">
            {[1, 2, 3].map((j) => (<div key={j} className="h-3 bg-gray-100 rounded" />))}
          </div>
        </div>
      ))}
    </div>
  );
}

function ErrorState({ error, onRetry }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mb-4">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="1.5">
          <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
        </svg>
      </div>
      <h3 className="text-base font-semibold text-gray-700 mb-1">Failed to load user</h3>
      <p className="text-sm text-gray-400 mb-4">{error}</p>
      <button onClick={onRetry} className="text-sm font-medium text-blue-600 hover:text-blue-700 border border-blue-200 px-4 py-2 rounded-lg hover:bg-blue-50">
        Try Again
      </button>
    </div>
  );
}
