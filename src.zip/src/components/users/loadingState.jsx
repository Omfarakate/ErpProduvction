export default function LoadingSkeleton({ view }) {
  const count = view === "grid" ? 8 : 5;
  return (
    <div className={view === "grid" ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" : "flex flex-col gap-3"}>
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="bg-white rounded-xl border border-gray-100 p-4 shimmer h-20" />
      ))}
    </div>
  );
}