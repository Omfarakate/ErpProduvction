"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import UserAvatar from "./UserAvatar";
import { toast } from "@/lib/toast";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

function getCurrentUser() {
  if (typeof window === "undefined") return null;
  const stored = localStorage.getItem("pp_user") || sessionStorage.getItem("pp_user");
  return stored ? JSON.parse(stored) : null;
}

export default function UserGridView({ users, isSuperAdmin }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {users.map(user => (
        <UserGridCard key={user.id} user={user} isSuperAdmin={isSuperAdmin} />
      ))}
    </div>
  );
}

function UserGridCard({ user, isSuperAdmin }) {
  const router = useRouter();
  const [loginAsLoading, setLoginAsLoading] = useState(false);
  const isActive = user.isActive !== false && user.isActive !== "Inactive";
  const groupName = user.userGroupCompanies?.[0]?.group?.groupName || "-";
  const companyName = user.userGroupCompanies?.[0]?.company?.companyName || "-";
  const fullName = [user.firstName, user.lastName].filter(Boolean).join(" ") || user.userName || "-";

  const handleLoginAs = async () => {
    const adminUser = getCurrentUser();
    if (!adminUser) return;
    setLoginAsLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/user/login-as`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          adminEmail: adminUser.email,
          targetUserId: user.id
        }),
      });
      const data = await res.json();
      if (data?.settings?.success === 1) {
        const adminSession = localStorage.getItem("pp_user") || sessionStorage.getItem("pp_user");
        localStorage.setItem("pp_admin_session", adminSession);
        localStorage.setItem("pp_impersonating", "true");
        const targetData = data.settings.data.targetUser;
        sessionStorage.setItem("pp_user", JSON.stringify(targetData));
        localStorage.removeItem("pp_user");
        toast.success(`Logged in as ${targetData.firstName || targetData.userName}`);
        setTimeout(() => router.push("/dashboard"), 1000);
      } else {
        toast.error(data?.settings?.message || "Failed");
      }
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoginAsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow p-4 flex flex-col gap-3 relative">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <UserAvatar user={user} size={40} />
            <span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white ${isActive ? "bg-green-400" : "bg-red-600"}`} />
          </div>
          <div className="min-w-0">
            <button
              onClick={() => router.push(`/users/${user.id}`)}
              className="font-semibold text-blue-600 hover:text-blue-700 text-sm leading-tight truncate max-w-[350px] text-left hover:underline"
            >
              {fullName}
            </button>
            <p className="text-xs text-gray-400  max-w-[120px]">{user.email}</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-1.5 text-xs">
        <Row label="Group Name" value={groupName} />
        <Row label="User Name" value={user.userName || user.email} />
        <Row label="Company Name" value={companyName} />
        <Row label="Phone Number" value={user.phoneNumber || "-"} />
      </div>

      <div className="flex gap-2 pt-2 border-t border-gray-50">
        <button
          onClick={() => router.push(`/users/${user.id}`)}
          className="flex-1 text-xs font-medium text-blue-600 bg-blue-50 hover:bg-blue-100 py-1.5 rounded-lg transition-colors"
        >
          View
        </button>
        {isSuperAdmin && (
          <button
            onClick={handleLoginAs}
            disabled={loginAsLoading}
            className="flex-1 text-xs font-medium text-purple-600 bg-purple-50 hover:bg-purple-100 py-1.5 rounded-lg transition-colors disabled:opacity-50"
          >
            {loginAsLoading ? "…" : "Login As"}
          </button>
        )}
      </div>
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-gray-400 flex-shrink-0">{label}</span>
      <span className="text-gray-700 font-medium text-right">{value}</span>
    </div>
  );
}
