"use client";

import { useState, useEffect } from "react";

export default function useUsers(apiUrl, initialLimit = 10) {
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(1);
  const [limit] = useState(initialLimit);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);

  const fetchUsers = async (pageNumber = page) => {
    setLoading(true);
    try {
      const res = await fetch(`${apiUrl}?limit=${limit}&page=${pageNumber}`);
      const data = await res.json();
      if (data.success) {
        setUsers(data.data.list);
        setTotalPages(data.data.pagination.total_pages);
      } else {
        console.error(data.message);
      }
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchUsers(page);
  }, [page]);

  return { users, page, totalPages, setPage, loading, refetch: fetchUsers };
}