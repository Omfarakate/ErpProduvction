"use client";

import React from "react";

export default function UserTable({ users }) {
  return (
    <div className="overflow-x-auto bg-white rounded-2xl shadow border border-gray-100">
      <table className="w-full text-left">
        <thead className="bg-gray-50 border-b border-gray-100">
          <tr>
            <th className="px-6 py-4 text-sm font-semibold text-gray-600">Name</th>
            <th className="px-6 py-4 text-sm font-semibold text-gray-600">Email</th>
            <th className="px-6 py-4 text-sm font-semibold text-gray-600">Groups</th>
            <th className="px-6 py-4 text-sm font-semibold text-gray-600">Status</th>
            <th className="px-6 py-4 text-right text-sm font-semibold text-gray-600">Actions</th>
          </tr>
        </thead>
        <tbody>
          {users?.map((user) => (
            <tr key={user.id} className="border-b border-gray-100 hover:bg-gray-50">
              <td className="px-6 py-4">{user.firstName}</td>
              <td className="px-6 py-4">{user.email}</td>
              <td className="px-6 py-4">
                {user.userGroupCompanies?.map((ugc) => ugc.group.groupName).join(", ") || "-"}
              </td>
              <td className="px-6 py-4">{user.isActive ? "Active" : "Inactive"}</td>
              <td className="px-6 py-4 text-right">
                <button className="text-blue-600 hover:text-blue-800 mr-2">Edit</button>
                <button className="text-red-500 hover:text-red-700">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}