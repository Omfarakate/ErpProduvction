export default function SortIcon({
  active,
  dir,
}) {
  return (
    <span
      className={`inline-flex flex-col gap-px ${
        active
          ? "text-blue-600"
          : "text-gray-300"
      }`}
    >
      <svg
        width="8"
        height="5"
        viewBox="0 0 8 5"
        fill="currentColor"
        className={
          active && dir === "asc"
            ? "text-blue-600"
            : "text-gray-300"
        }
      >
        <path d="M4 0L8 5H0L4 0Z" />
      </svg>

      <svg
        width="8"
        height="5"
        viewBox="0 0 8 5"
        fill="currentColor"
        className={
          active && dir === "desc"
            ? "text-blue-600"
            : "text-gray-300"
        }
      >
        <path d="M4 5L0 0H8L4 5Z" />
      </svg>
    </span>
  );
}