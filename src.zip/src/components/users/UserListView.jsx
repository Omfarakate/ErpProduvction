"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import UserAvatar from "./UserAvatar";
import { toast } from "@/lib/toast";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

function getCurrentUser() {
  if (typeof window === "undefined") return null;
  const stored = localStorage.getItem("pp_user") || sessionStorage.getItem("pp_user");
  return stored ? JSON.parse(stored) : null;
}

export default function UserListView({ users, isSuperAdmin }) {
  return (
    <div className="flex flex-col gap-2">
      {users.map((user) => (
        <UserListRow key={user.id} user={user} isSuperAdmin={isSuperAdmin} />
      ))}
    </div>
  );
}

function UserListRow({ user, isSuperAdmin }) {
  const router = useRouter();
  const [expanded, setExpanded] = useState(false);
  const [loginAsLoading, setLoginAsLoading] = useState(false);

  const handleLoginAs = async () => {
    const adminUser = getCurrentUser();
    if (!adminUser) return;
    setLoginAsLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/user/login-as`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          adminEmail: adminUser.email,
          targetUserId: user.id
        }),
      });
      const data = await res.json();
      if (data?.settings?.success === 1) {
        const adminSession = localStorage.getItem("pp_user") || sessionStorage.getItem("pp_user");
        localStorage.setItem("pp_admin_session", adminSession);
        localStorage.setItem("pp_impersonating", "true");
        const targetData = data.settings.data.targetUser;
        sessionStorage.setItem("pp_user", JSON.stringify(targetData));
        localStorage.removeItem("pp_user");
        toast.success(`Logged in as ${targetData.firstName || targetData.userName}`);
        setTimeout(() => router.push("/dashboard"), 1000);
      } else {
        toast.error(data?.settings?.message || "Login As failed");
      }
    } catch (e) {
      toast.error("Login As failed: " + e.message);
    } finally {
      setLoginAsLoading(false);
    }
  };

  const isActive = user.isActive !== false && user.isActive !== "Inactive";
  const groupName = user.userGroupCompanies?.[0]?.group?.groupName || "—";
  const companyName = user.userGroupCompanies?.[0]?.company?.companyName || "—";
  const fullName =
    [user.firstName, user.lastName].filter(Boolean).join(" ") ||
    user.userName ||
    "—";
  const lastAccess = user.lastLogin
    ? new Date(user.lastLogin).toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "—";

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="grid grid-cols-[1fr_1fr_auto_1fr_auto] gap-4 px-5 py-4 items-center">
        {/* Name + avatar */}
        <div>
          <div className="text-xs text-gray-400 mb-1">Name</div>
          <div className="flex items-center gap-2.5">
            <div className="relative flex-shrink-0">
              <UserAvatar user={user} size={36} />
              <span
                className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white ${
                  isActive ? "bg-green-400" : "bg-red-600"
                }`}
              />
            </div>
            <div>
              <button
                onClick={() => router.push(`/users/${user.id}`)}
                className="font-semibold text-blue-600 hover:text-blue-700 hover:underline text-sm leading-tight text-left"
              >
                {fullName}
              </button>
              <p className="text-xs text-gray-400">{user.phoneNumber || ""}</p>
            </div>
          </div>
        </div>

        {/* Username */}
        <div>
          <div className="text-xs text-gray-400 mb-1">User Name</div>
          <p className="text-sm text-gray-700">{user.userName || user.email}</p>
        </div>

        {/* Status */}
        <div>
          <div className="text-xs text-gray-400 mb-1">Status</div>
          <span
            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${
              isActive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-500"
            }`}
          >
            {isActive ? "Active" : "Inactive"}
          </span>
        </div>

        {/* Company */}
        <div>
          <div className="text-xs text-gray-400 mb-1">Company</div>
          <p className="text-sm font-medium text-blue-600">{companyName}</p>
        </div>

        {/* Expand */}
        <button
          onClick={() => setExpanded((v) => !v)}
          className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-gray-100 text-gray-400 transition-all"
        >
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className={`transition-transform duration-200 ${expanded ? "rotate-180" : ""}`}
          >
            <polyline points="6 9 12 15 18 9" />
          </svg>
        </button>
      </div>

      {/* Expanded detail */}
      {expanded && (
        <div className="border-t border-gray-50 bg-gray-50/50 px-5 py-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
            <Detail label="Email" value={user.email} />
            <Detail
              label="Date Of Birth"
              value={user.birthDate ? new Date(user.birthDate).toLocaleDateString() : "—"}
            />
            <Detail label="Group" value={groupName} />
            <Detail label="Last Access" value={lastAccess} />
          </div>
          <div className="flex gap-2 mt-4 pt-3 border-t border-gray-100">
            <button
              onClick={() => router.push(`/users/${user.id}`)}
              className="text-xs font-medium text-blue-600 hover:text-blue-700 px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors"
            >
              View Details
            </button>
            {isSuperAdmin && (
              <>
                <button
                  onClick={() => router.push(`/users/${user.id}/edit`)}
                  className="text-xs font-medium text-blue-600 hover:text-blue-700 px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors"
                >
                  Edit
                </button>
                <button
                  onClick={handleLoginAs}
                  disabled={loginAsLoading}
                  className="text-xs font-medium text-purple-600 hover:text-purple-700 px-3 py-1.5 rounded-lg bg-purple-50 hover:bg-purple-100 transition-colors disabled:opacity-50"
                >
                  {loginAsLoading ? "…" : "Login As"}
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function Detail({ label, value }) {
  return (
    <div>
      <div className="text-xs text-gray-400 mb-0.5">{label}</div>
      <div className="text-sm text-gray-700 font-medium">{value}</div>
    </div>
  );
}
