"use client";

const COLORS = [
  "#2563eb", "#7c3aed", "#059669", "#dc2626",
  "#d97706", "#0891b2", "#be185d", "#4f46e5",
];

function getColor(name = "") {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return COLORS[Math.abs(hash) % COLORS.length];
}

function getInitials(user) {
  const first = user.firstName?.[0] || "";
  const last = user.lastName?.[0] || "";
  if (first || last) return (first + last).toUpperCase();
  return (user.userName?.[0] || user.email?.[0] || "?").toUpperCase();
}

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

function getImageUrl(profImg, userId) {
  if (!profImg) return null;
  if (profImg.startsWith("http")) return profImg;
  // Image structure: uploads/profileImg/{userId}/{filename}
  if (userId) {
    const filename = profImg.split('/').pop();
    return `${API_BASE}/uploads/profileImg/${userId}/${filename}`;
  }
  return `${API_BASE}/uploads/${profImg}`;
}

export default function UserAvatar({ user, size = 36 }) {
  const initials = getInitials(user);
  const color = getColor(initials);
  const fontSize = size * 0.38;
  const imgUrl = getImageUrl(user.profImg, user.id);


  if (imgUrl) {
    return (
      <img
        src={imgUrl}
        alt={initials}
        width={size}
        height={size}
        className="rounded-full object-cover flex-shrink-0"
        style={{ width: size, height: size }}
        onError={(e) => {
          e.currentTarget.style.display = "none";
          const fallback = e.currentTarget.nextElementSibling;
          if (fallback) fallback.style.display = "flex";
        }}
      />
    );
  }

  return (
    <div
      className="rounded-full flex items-center justify-center flex-shrink-0 font-bold text-white"
      style={{ width: size, height: size, background: color, fontSize }}
    >
      {initials}
    </div>
  );
}

