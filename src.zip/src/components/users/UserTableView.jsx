"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import UserAvatar from "./UserAvatar";
import SortIcon from "./sortIcon";
import { toast } from "@/lib/toast";

const COLUMNS = [
  { key: "name", label: "Name", sortable: true },
  { key: "email", label: "Email", sortable: true },
  { key: "phoneNumber", label: "Phone Number", sortable: false },
  { key: "userName", label: "User Name", sortable: true },
  { key: "groupName", label: "Group Name", sortable: false },
  { key: "status", label: "Status", sortable: true },
];

function getCurrentUser() {
  if (typeof window === "undefined") return null;

  const stored =
    localStorage.getItem("pp_user") ||
    sessionStorage.getItem("pp_user");

  return stored ? JSON.parse(stored) : null;
}

export default function UserTableView({
  users,
  isSuperAdmin,
}) {
  const router = useRouter();

  const [sortKey, setSortKey] = useState(null);
  const [sortDir, setSortDir] = useState("asc");
  const [selected, setSelected] = useState([]);
  const [loginAsLoading, setLoginAsLoading] =
    useState(null);

  const [filters, setFilters] = useState({
    name: "",
    email: "",
    phoneNumber: "",
    userName: "",
    groupName: "",
    status: "",
  });

  const BASE_URL =
    process.env.NEXT_PUBLIC_API_URL ||
    "http://localhost:4000";

  const showToast = (msg, type = "success") => {
    if (type === "error") toast.error(msg);
    else toast.success(msg);
  };

  const handleSort = (key) => {
    if (sortKey === key) {
      setSortDir((d) =>
        d === "asc" ? "desc" : "asc"
      );
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const filteredUsers = users.filter((user) => {
    const fullName = [
      user.firstName,
      user.lastName,
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();

    const groupName =
      user.userGroupCompanies?.[0]?.group?.groupName?.toLowerCase() ||
      "";

    const status =
      user.isActive !== false &&
      user.isActive !== "Inactive"
        ? "active"
        : "inactive";

    return (
      fullName.includes(
        filters.name.toLowerCase()
      ) &&
      (user.email || "")
        .toLowerCase()
        .includes(filters.email.toLowerCase()) &&
      (user.phoneNumber || "")
        .toLowerCase()
        .includes(
          filters.phoneNumber.toLowerCase()
        ) &&
      (user.userName || "")
        .toLowerCase()
        .includes(
          filters.userName.toLowerCase()
        ) &&
      groupName.includes(
        filters.groupName.toLowerCase()
      ) &&
      status.includes(
        filters.status.toLowerCase()
      )
    );
  });

  const sorted = [...filteredUsers].sort(
    (a, b) => {
      if (!sortKey) return 0;

      let aVal = "";
      let bVal = "";

      if (sortKey === "name") {
        aVal = [
          a.firstName,
          a.lastName,
        ]
          .filter(Boolean)
          .join(" ");

        bVal = [
          b.firstName,
          b.lastName,
        ]
          .filter(Boolean)
          .join(" ");
      } else if (sortKey === "groupName") {
        aVal =
          a.userGroupCompanies?.[0]?.group
            ?.groupName || "";

        bVal =
          b.userGroupCompanies?.[0]?.group
            ?.groupName || "";
      } else if (sortKey === "status") {
        aVal =
          a.isActive !== false &&
          a.isActive !== "Inactive"
            ? "Active"
            : "Inactive";

        bVal =
          b.isActive !== false &&
          b.isActive !== "Inactive"
            ? "Active"
            : "Inactive";
      } else {
        aVal = a[sortKey] || "";
        bVal = b[sortKey] || "";
      }

      const cmp = String(aVal).localeCompare(
        String(bVal)
      );

      return sortDir === "asc"
        ? cmp
        : -cmp;
    }
  );

  const toggleSelect = (id) => {
    setSelected((prev) =>
      prev.includes(id)
        ? prev.filter((x) => x !== id)
        : [...prev, id]
    );
  };

  const toggleAll = () => {
    setSelected((prev) =>
      prev.length === users.length
        ? []
        : users.map((u) => u.id)
    );
  };

  const handleView = (userId) => {
    router.push(`/users/${userId}`);
  };

  const handleLoginAs = async (
    targetUser
  ) => {
    const adminUser = getCurrentUser();

    if (!adminUser) return;

    setLoginAsLoading(targetUser.id);

    try {
      const res = await fetch(
        `${BASE_URL}/user/login-as`,
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/json",
          },
          body: JSON.stringify({
            adminEmail: adminUser.email,
            targetUserId:
              targetUser.id,
          }),
        }
      );

      const data = await res.json();

      if (
        data?.settings?.success === 1
      ) {
        const adminSession =
          localStorage.getItem(
            "pp_user"
          ) ||
          sessionStorage.getItem(
            "pp_user"
          );

        localStorage.setItem(
          "pp_admin_session",
          adminSession
        );

        localStorage.setItem(
          "pp_impersonating",
          "true"
        );

        const targetData =
          data.settings.data.targetUser;

        sessionStorage.setItem(
          "pp_user",
          JSON.stringify(targetData)
        );

        localStorage.removeItem(
          "pp_user"
        );

        showToast(
          `Now logged in as ${
            targetData.firstName ||
            targetData.userName
          }`
        );

        setTimeout(() => {
          router.push("/dashboard");
        }, 1000);
      } else {
        showToast(
          data?.settings?.message ||
            "Login As failed",
          "error"
        );
      }
    } catch (e) {
      showToast(
        "Login As failed: " + e.message,
        "error"
      );
    } finally {
      setLoginAsLoading(null);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden relative">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 border-b border-gray-100">
            <tr>
              <th className="px-4 py-3 w-10">
                <input
                  type="checkbox"
                  checked={
                    selected.length ===
                      users.length &&
                    users.length > 0
                  }
                  onChange={toggleAll}
                  className="w-4 h-4 accent-blue-600 rounded"
                />
              </th>

              {COLUMNS.map((col) => (
                <th
                  key={col.key}
                  className="px-4 py-3 font-semibold text-gray-500 whitespace-nowrap"
                >
                  {col.sortable ? (
                    <button
                      onClick={() =>
                        handleSort(col.key)
                      }
                      className="flex items-center gap-1 hover:text-gray-900 transition-colors"
                    >
                      {col.label}

                      <SortIcon
                        active={
                          sortKey === col.key
                        }
                        dir={sortDir}
                      />
                    </button>
                  ) : (
                    col.label
                  )}
                </th>
              ))}

              <th className="px-4 py-3 text-right font-semibold text-gray-500">
                Actions
              </th>
            </tr>

            <tr className="text-black bg-white border-b border-gray-100">
              <th></th>

              <th className="px-4 py-2">
                <input
                  type="text"
                  placeholder="Search Name"
                  value={filters.name}
                  onChange={(e) =>
                    setFilters({
                      ...filters,
                      name: e.target.value,
                    })
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500"
                />
              </th>

              <th className="px-4 py-2">
                <input
                  type="text"
                  placeholder="Search Email"
                  value={filters.email}
                  onChange={(e) =>
                    setFilters({
                      ...filters,
                      email:
                        e.target.value,
                    })
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500"
                />
              </th>

              <th className="px-4 py-2">
                <input
                  type="text"
                  placeholder="Search Phone"
                  value={filters.phoneNumber}
                  onChange={(e) =>
                    setFilters({
                      ...filters,
                      phoneNumber:
                        e.target.value,
                    })
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500"
                />
              </th>

              <th className="px-4 py-2">
                <input
                  type="text"
                  placeholder="Search Username"
                  value={filters.userName}
                  onChange={(e) =>
                    setFilters({
                      ...filters,
                      userName:
                        e.target.value,
                    })
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500"
                />
              </th>

              <th className="px-4 py-2">
                <input
                  type="text"
                  placeholder="Search Group"
                  value={filters.groupName}
                  onChange={(e) =>
                    setFilters({
                      ...filters,
                      groupName:
                        e.target.value,
                    })
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500"
                />
              </th>

              <th className="px-4 py-2">
                <select
                  value={filters.status}
                  onChange={(e) =>
                    setFilters({
                      ...filters,
                      status:
                        e.target.value,
                    })
                  }
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500"
                >
                  <option value="">
                    All
                  </option>

                  <option value="active">
                    Active
                  </option>

                  <option value="inactive">
                    Inactive
                  </option>
                </select>
              </th>

              <th></th>
            </tr>
          </thead>

          <tbody className="divide-y divide-gray-50">
            {sorted.map((user) => {
              const isActive =
                user.isActive !== false &&
                user.isActive !==
                  "Inactive";

              const groupName =
                user
                  .userGroupCompanies?.[0]
                  ?.group?.groupName ||
                "—";

              const fullName = [
                user.firstName,
                user.lastName,
              ]
                .filter(Boolean)
                .join(" ");

              const isSelected =
                selected.includes(
                  user.id
                );

              const isLoadingAs =
                loginAsLoading ===
                user.id;

              return (
                <tr
                  key={user.id}
                  className={`hover:bg-blue-50/30 transition-colors ${
                    isSelected
                      ? "bg-blue-50/50"
                      : ""
                  }`}
                >
                  <td className="px-4 py-3">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() =>
                        toggleSelect(
                          user.id
                        )
                      }
                      className="w-4 h-4 accent-blue-600 rounded"
                    />
                  </td>

                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <UserAvatar
                        user={user}
                        size={32}
                      />

                      <button
                        onClick={() =>
                          handleView(
                            user.id
                          )
                        }
                        className="font-medium text-blue-600 hover:text-blue-700 hover:underline transition-colors text-left"
                      >
                        {fullName}
                      </button>
                    </div>
                  </td>

                  <td className="px-4 py-3 text-gray-600">
                    {user.email}
                  </td>

                  <td className="px-4 py-3 text-gray-600">
                    {user.phoneNumber ||
                      "—"}
                  </td>

                  <td className="px-4 py-3 text-gray-600">
                    {user.userName ||
                      user.email}
                  </td>

                  <td className="px-4 py-3 text-gray-600">
                    {groupName}
                  </td>

                  <td className="px-4 py-3">
                    <span
                      className={`font-semibold text-sm ${
                        isActive
                          ? "text-green-600"
                          : "text-red-400"
                      }`}
                    >
                      {isActive
                        ? "Active"
                        : "Inactive"}
                    </span>
                  </td>

                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      {/* <button
                        onClick={() =>
                          handleView(
                            user.id
                          )
                        }
                        className="text-xs text-blue-500 hover:text-blue-700 font-medium transition-colors px-2 py-1 rounded hover:bg-blue-50"
                      >
                        View
                      </button> */}

                      {isSuperAdmin && (
                        <>
                          <span className="text-gray-200">
                            |
                          </span>

                          <button
                            onClick={() => router.push(`/users/${user.id}/edit`)}
                            className="text-xs text-gray-500 hover:text-gray-700 font-medium transition-colors px-2 py-1 rounded hover:bg-gray-50">
                            Edit
                          </button>

                          <span className="text-gray-200">
                            |
                          </span>

                          <button
                            onClick={() =>
                              handleLoginAs(
                                user
                              )
                            }
                            disabled={
                              isLoadingAs
                            }
                            className="text-xs text-purple-500 hover:text-purple-700 font-medium transition-colors px-2 py-1 rounded hover:bg-purple-50 disabled:opacity-50 whitespace-nowrap"
                          >
                            {isLoadingAs
                              ? "..."
                              : "Login As"}
                          </button>

                          <span className="text-gray-200">
                            |
                          </span>

                          {/* <button className="text-xs text-red-400 hover:text-red-600 font-medium transition-colors px-2 py-1 rounded hover:bg-red-50">
                            Delete
                          </button> */}
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
