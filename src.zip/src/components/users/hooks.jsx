"use client";

import { useState, useEffect, useCallback } from "react";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000";

export default function useUsers(initialLimit = 10) {
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(1);
  const [limit] = useState(initialLimit);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const fetchUsers = useCallback(async (pageNum, searchVal, statusVal) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ limit, page: pageNum });
      if (searchVal) params.set("search", searchVal);
      if (statusVal && statusVal !== "all") params.set("status", statusVal);
      const url = `${BASE_URL}/user/users-list?${params.toString()}`;
      const encoded = btoa(url);
      const res = await fetch(`/relayApi?path=${encoded}`);
      const data = await res.json();
      if (data?.success) {
        setUsers(data.data.list || []);
        setTotalPages(data.data.pagination?.total_pages || 1);
        setTotalCount(data.data.pagination?.total_count || 0);
      }
    } catch {
      setUsers([]);
    } finally {
      setLoading(false);
    }
  }, [limit]);

  useEffect(() => {
    fetchUsers(page, search, statusFilter);
  }, [page, search, statusFilter, fetchUsers]);

  const handleSearch = (val) => {
    setSearch(val);
    setPage(1);
  };

  const handleStatusFilter = (val) => {
    setStatusFilter(val);
    setPage(1);
  };

  return {
    users,
    page,
    totalPages,
    totalCount,
    setPage,
    loading,
    search,
    statusFilter,
    handleSearch,
    handleStatusFilter,
    refetch: () => fetchUsers(page, search, statusFilter),
  };
}
