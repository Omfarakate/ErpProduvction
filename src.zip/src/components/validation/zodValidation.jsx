import { z } from "zod";

export const step1Schema = z
  .object({
    email: z
      .string()
      .min(1, "Email is required")
      .email("Enter valid email"),

    password: z
      .string()
      .min(6, "Password must be at least 6 characters"),

    confirmPassword: z
      .string()
      .min(1, "Confirm password is required"),
  })
  .refine((data) => data.password === data.confirmPassword, {
    path: ["confirmPassword"],
    message: "Passwords do not match",
  });

export const step2Schema = z.object({
  firstName: z
    .string()
    .min(1, "First name is required"),

  lastName: z
    .string()
    .min(1, "Last name is required"),

  userName: z
    .string()
    .min(1, "Username is required")
    .regex(/^\S+$/, "No spaces allowed"),

  phoneNumber: z
    .string()
    .min(10, "Phone number is required")
    .regex(
      /^\+?[\d\s\-]{7,15}$/,
      "Enter valid phone number"
    ),

  birthDate: z
    .string()
    .min(1, "Date of birth is required")
    .refine((date) => {
      const birthDate = new Date(date);
      const today = new Date();
      const age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        return age - 1 >= 18;
      }
      return age >= 18;
    }, "User must be at least 18 years old"),
});

export const fullSignupSchema =
  step1Schema.safeExtend(step2Schema.shape);