"use client";

import Image from "next/image";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="">
      {/* <div className="max-w-6xl mx-auto px-4 sm:px-6"> */}
        
        {/* Footer Top */}
        <div className="">
        {/* Divider */}
        <div className="justify-center flex">
          <div className="flex flex-col md:flex-row items-center justify-between text-sm text-gray-400">
            
            <p>
              &copy; {currentYear} Production Planning Platform. All rights reserved.
            </p>
          </div>
        </div>

      </div>
    </footer>
  );
}