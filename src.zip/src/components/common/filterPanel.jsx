"use client"; 

import { useState, useEffect, useRef } from "react";

export default function FilterPanel({ onApply }) {
  const [filters, setFilters] = useState({
    name: "",
    email: "",
    groupName: "",
    companyName: "",
    status: "",
  });

  const debounceRef = useRef(null);

  const update = (key, val) => {
    const next = { ...filters, [key]: val };
    setFilters(next);

    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      onApply(next);
    }, 400);
  };

  const handleReset = () => {
    const empty = { name: "", email: "", groupName: "", companyName: "", status: "" };
    setFilters(empty);
    clearTimeout(debounceRef.current);
    onApply(empty);
  };

  useEffect(() => {
    return () => clearTimeout(debounceRef.current);
  }, []);

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-4">
        <FilterField
          label="Name"
          placeholder="Please enter Name"
          value={filters.name}
          onChange={(v) => update("name", v)}
        />
        <FilterField
          label="Email"
          placeholder="Please enter Email"
          value={filters.email}
          onChange={(v) => update("email", v)}
        />
        <FilterField
          label="Group Name"
          placeholder="Select Group Name"
          value={filters.groupName}
          onChange={(v) => update("groupName", v)}
          select
        />
        <FilterField
          label="Company Name"
          placeholder="Select Company Name"
          value={filters.companyName}
          onChange={(v) => update("companyName", v)}
          select
        />
        <FilterField
          label="Status"
          placeholder="Select Status"
          value={filters.status}
          onChange={(v) => update("status", v)}
          select
          options={["Active", "Inactive"]}
        />
      </div>

      <div className="px-5 py-4 border-t border-gray-100">
        <button
          onClick={handleReset}
          className="w-full text-sm font-medium text-gray-600 border border-gray-200 py-2 rounded-lg hover:bg-gray-50 transition-colors"
        >
          Reset Filters
        </button>
      </div>
    </div>
  );
}

function FilterField({ label, placeholder, value, onChange, select, options }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1.5">{label}</label>
      {select ? (
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 text-gray-600 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">{placeholder}</option>
          {(options || []).map((o) => (
            <option key={o} value={o}>{o}</option>
          ))}
        </select>
      ) : (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 text-gray-600 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      )}
    </div>
  );
}
