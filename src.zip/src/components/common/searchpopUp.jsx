"use client"; 

import { useState, useRef, useEffect } from "react";

export default function SearchPopup({ onClose, onSearch, fields }) {
  const [condition, setCondition] = useState("All");
  const [rows, setRows] = useState([{ field: fields?.[0] || "Name", op: "equal", value: "" }]);
  const popupRef = useRef(null);

  const availableFields = fields || ["Name", "Email", "Phone Number", "User Name", "Group Name"];

  useEffect(() => {
    const handler = (e) => {
      if (popupRef.current && !popupRef.current.contains(e.target)) {
        onClose();
      }
    };
    const t = setTimeout(() => document.addEventListener("mousedown", handler), 100);
    return () => {
      clearTimeout(t);
      document.removeEventListener("mousedown", handler);
    };
  }, [onClose]);

  const addRow = () =>
    setRows((prev) => [...prev, { field: availableFields[0], op: "equal", value: "" }]);

  const removeRow = (i) =>
    setRows((prev) => prev.filter((_, idx) => idx !== i));

  const updateRow = (i, key, val) =>
    setRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, [key]: val } : r)));

  const handleFind = () => {
    const filters = rows
      .filter((r) => r.value.trim())
      .map((r) => ({ field: r.field, op: r.op, value: r.value }));
    onSearch({ condition, filters });
  };

  const handleReset = () => {
    setRows([{ field: availableFields[0], op: "equal", value: "" }]);
    onSearch({ condition: "All", filters: [] });
  };

  return (
    <div
      ref={popupRef}
      className="fixed left-0 top-10 z-[999] bg-white border border-gray-200 rounded-xl shadow-2xl w-[500px] p-4"
      onClick={(e) => e.stopPropagation()} 
    >
      {/* Close */}
      <button
        onClick={onClose}
        className="absolute top-3 right-3 w-6 h-6 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-400"
      >
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
          <line x1="18" y1="6" x2="6" y2="18" />
          <line x1="6" y1="6" x2="18" y2="18" />
        </svg>
      </button>

      {/* Condition + Add row */}
      <div className="flex items-center gap-2 mb-3 pr-8">
        <select
          value={condition}
          onChange={(e) => setCondition(e.target.value)}
          className="text-sm border border-gray-200 rounded-lg px-2 py-1.5 text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="All">All</option>
          <option value="Any">Any</option>
        </select>
        <button
          onClick={addRow}
          className="w-7 h-7 bg-blue-600 text-white rounded-lg flex items-center justify-center hover:bg-blue-700 font-bold text-base"
        >
          +
        </button>
      </div>

      {/* Filter rows */}
      <div className="flex flex-col gap-2 mb-4">
        {rows.map((row, i) => (
          <div key={i} className="flex items-center gap-2">
            <select
              value={row.field}
              onChange={(e) => updateRow(i, "field", e.target.value)}
              className="w-36 text-sm border border-gray-200 rounded-lg px-2 py-1.5 text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {availableFields.map((f) => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>

            <select
              value={row.op}
              onChange={(e) => updateRow(i, "op", e.target.value)}
              className="w-32 text-sm border border-gray-200 rounded-lg px-2 py-1.5 text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="equal">equal</option>
              <option value="contains">contains</option>
              <option value="starts_with">starts with</option>
              <option value="ends_with">ends with</option>
            </select>

            <input
              value={row.value}
              onChange={(e) => updateRow(i, "value", e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleFind()}
              className="flex-1 text-sm border border-gray-200 rounded-lg px-2 py-1.5 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Value..."
              autoFocus={i === rows.length - 1}
            />

            {rows.length > 1 && (
              <button
                onClick={() => removeRow(i)}
                className="w-7 h-7 flex items-center justify-center bg-gray-100 hover:bg-red-100 text-gray-500 hover:text-red-500 rounded-lg font-bold text-sm flex-shrink-0"
              >
                −
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between">
        <button
          onClick={handleReset}
          className="text-sm font-medium text-gray-600 border border-gray-200 px-4 py-1.5 rounded-lg hover:bg-gray-50"
        >
          Reset
        </button>
        <button
          onClick={handleFind}
          className="text-sm font-semibold text-white bg-blue-600 px-6 py-1.5 rounded-lg hover:bg-blue-700"
        >
          Find
        </button>
      </div>
    </div>
  );
}
