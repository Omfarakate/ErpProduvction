export default function Illustration() {
  return (
    <svg viewBox="0 0 560 440" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: "80%", maxWidth: 500 }}>
      <ellipse cx="280" cy="240" rx="210" ry="170" fill="rgba(255,255,255,0.04)" />
      <rect x="170" y="90" width="260" height="185" rx="12" fill="#c7d9f8" opacity="0.22" />
      <rect x="184" y="104" width="65" height="158" rx="6" fill="#a5b4fc" opacity="0.32" />
      <rect x="259" y="104" width="65" height="158" rx="6" fill="#93c5fd" opacity="0.32" />
      <rect x="334" y="104" width="82" height="158" rx="6" fill="#60a5fa" opacity="0.32" />
      <rect x="189" y="111" width="52" height="26" rx="4" fill="white" opacity="0.5" />
      <rect x="189" y="144" width="52" height="18" rx="4" fill="white" opacity="0.32" />
      <rect x="189" y="170" width="52" height="18" rx="4" fill="white" opacity="0.32" />
      <rect x="264" y="111" width="52" height="26" rx="4" fill="white" opacity="0.5" />
      <rect x="264" y="144" width="52" height="18" rx="4" fill="white" opacity="0.32" />
      <rect x="340" y="111" width="68" height="26" rx="4" fill="#f59e0b" opacity="0.6" />
      <rect x="340" y="144" width="68" height="18" rx="4" fill="white" opacity="0.32" />
      <rect x="316" y="214" width="34" height="34" rx="6" fill="#22c55e" opacity="0.7" />
      <polyline points="323,231 330,238 344,224" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <circle cx="206" cy="300" r="68" fill="white" opacity="0.92" />
      <circle cx="206" cy="300" r="68" stroke="#f59e0b" strokeWidth="6" fill="none" />
      <path d="M206 300 L206 232 A68 68 0 0 1 274 300 Z" fill="#f59e0b" opacity="0.85" />
      <line x1="206" y1="300" x2="206" y2="252" stroke="#ef4444" strokeWidth="3" strokeLinecap="round" />
      <line x1="206" y1="300" x2="232" y2="315" stroke="#9ca3af" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="206" cy="300" r="5" fill="#374151" />
      <g transform="translate(122,124) rotate(15)">
        <circle cx="0" cy="0" r="30" fill="none" stroke="#f59e0b" strokeWidth="5" opacity="0.48" />
        <circle cx="0" cy="0" r="12" fill="none" stroke="#f59e0b" strokeWidth="4" opacity="0.48" />
        {[0,45,90,135,180,225,270,315].map((a, i) => (
          <rect key={i} x="-4.5" y="-35" width="9" height="11" rx="2" fill="#f59e0b" opacity="0.48" transform={`rotate(${a})`} />
        ))}
      </g>
      <g transform="translate(408,158) rotate(-10)">
        <circle cx="0" cy="0" r="20" fill="none" stroke="#f59e0b" strokeWidth="4.5" opacity="0.48" />
        <circle cx="0" cy="0" r="8" fill="none" stroke="#f59e0b" strokeWidth="3.5" opacity="0.48" />
        {[0,60,120,180,240,300].map((a, i) => (
          <rect key={i} x="-3.5" y="-24" width="7" height="9" rx="2" fill="#f59e0b" opacity="0.48" transform={`rotate(${a})`} />
        ))}
      </g>
      <g transform="translate(138,312)">
        <ellipse cx="0" cy="-18" rx="11" ry="15" fill="#f97316" />
        <circle cx="0" cy="-38" r="11" fill="#fde68a" />
        <line x1="9" y1="-26" x2="26" y2="-18" stroke="#f97316" strokeWidth="4.5" strokeLinecap="round" />
        <line x1="-4" y1="-5" x2="-9" y2="16" stroke="#7c3aed" strokeWidth="4.5" strokeLinecap="round" />
        <line x1="4" y1="-5" x2="9" y2="16" stroke="#7c3aed" strokeWidth="4.5" strokeLinecap="round" />
      </g>
      <g transform="translate(368,270)">
        <ellipse cx="0" cy="-18" rx="11" ry="15" fill="#ec4899" />
        <circle cx="0" cy="-38" r="11" fill="#fde68a" />
        <ellipse cx="0" cy="-50" rx="7" ry="5" fill="#1f2937" />
        <line x1="-9" y1="-28" x2="-26" y2="-37" stroke="#ec4899" strokeWidth="4.5" strokeLinecap="round" />
        <line x1="-4" y1="-5" x2="-7" y2="17" stroke="#7c3aed" strokeWidth="4.5" strokeLinecap="round" />
        <line x1="4" y1="-5" x2="7" y2="17" stroke="#7c3aed" strokeWidth="4.5" strokeLinecap="round" />
      </g>
      <circle cx="432" cy="246" r="20" stroke="white" strokeWidth="3.5" fill="none" opacity="0.65" />
      <line x1="446" y1="261" x2="459" y2="276" stroke="white" strokeWidth="3.5" strokeLinecap="round" opacity="0.65" />
      <rect x="346" y="82" width="76" height="16" rx="4" fill="white" opacity="0.38" />
      <rect x="346" y="104" width="56" height="13" rx="4" fill="white" opacity="0.28" />
      <rect x="346" y="123" width="68" height="13" rx="4" fill="#f59e0b" opacity="0.48" />
    </svg>
  );
}