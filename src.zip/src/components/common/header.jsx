"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import Logo from "@/components/common/logo";
import SearchPopup from "@/components/common/searchpopUp";
import FilterPanel from "@/components/common/filterPanel";

function getAdminSession() {
  if (typeof window === "undefined") return null;
  const s = localStorage.getItem("pp_admin_session");
  return s ? JSON.parse(s) : null;
}


function isImpersonating() {
  if (typeof window === "undefined") return false;
  return localStorage.getItem("pp_impersonating") === "true";
}

export default function Header({ user, onLogout, onSearch, onRefresh, searchFields }) {
  const router = useRouter();
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [filterPanelOpen, setFilterPanelOpen] = useState(false);
  const [headerSearch, setHeaderSearch] = useState("");
  const [impersonating, setImpersonating] = useState(false);
  const menuRef = useRef(null);
  const searchBtnRef = useRef(null);
  useEffect(() => {
    setImpersonating(isImpersonating());
  }, []);

  useEffect(() => {
    const handler = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);


// console.log("hello xyx", user.data.userName);

  const fullName =
    [user?.data?.firstName, user?.data?.lastName].filter(Boolean).join(" ") ||
    user?.data?.userName ||
    user?.userName ||
    user?.email ||
    "User";

  const groupName = user?.userGroupCompanies?.[0]?.group?.groupName || user?.role || "";
  const companyName = user?.userGroupCompanies?.[0]?.company?.companyName || "";
  const subtitle = [groupName, companyName ? `[${companyName}]` : ""].filter(Boolean).join(" ");

  const handleHeaderSearchKey = (e) => {
    if (e.key === "Enter" && onSearch) onSearch(headerSearch);
  };

  const handleRefresh = () => {
    if (onRefresh) onRefresh();
    else window.dispatchEvent(new CustomEvent("pp:refresh"));
  };

  const handleRestoreAdmin = () => {
    // alert("Click OK to proceed.");
    const adminSession = getAdminSession();
    if (!adminSession) return;
    const adminData = typeof adminSession === "string" ? adminSession : JSON.stringify(adminSession);
    localStorage.setItem("pp_user", adminData);
    sessionStorage.removeItem("pp_user");
    localStorage.removeItem("pp_admin_session");
    localStorage.removeItem("pp_impersonating");
    router.push("/users");
  };

  const handleLogout = () => {
    if (impersonating) handleRestoreAdmin();
    else onLogout();
  };

  const handleFilterApply = (filters) => {
    if (onSearch) onSearch(filters);
  };

  const handleSearchPopupApply = (filters) => {
    if (onSearch) onSearch(filters);
    setSearchOpen(false);
  };

  return (
    <>
      {/* Impersonation Banner */}
      {impersonating && (
        <div className="bg-amber-500 text-white text-sm px-4 py-2 flex items-center justify-between z-50 relative">
          <span className="font-medium">
            SuperAdmin Login .
          </span>
          <button
            onClick={handleRestoreAdmin}
            className="ml-4 bg-white text-amber-600 font-semibold text-xs px-3 py-1 rounded-lg hover:bg-amber-50"
          >
            Return to Admin
          </button>
        </div>
      )}

      <header className="bg-white border-b border-gray-100 px-4 sm:px-6 h-14 flex items-center justify-between sticky top-0 z-40 shadow-sm">
        {/* Left: Logo + quick search */}
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <Logo />
          <div className="hidden sm:flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 min-w-[180px] max-w-xs flex-1">
            <svg width="14" height="14" className="text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
            <input
              placeholder="Search…"
              value={headerSearch}
              onChange={(e) => setHeaderSearch(e.target.value)}
              onKeyDown={handleHeaderSearchKey}
              className="bg-transparent text-sm text-gray-600 placeholder-gray-400 outline-none w-full"
            />
            <button
              onClick={() => onSearch && onSearch(headerSearch)}
              className="text-xs text-gray-400 border-l border-gray-200 pl-2 ml-1 hover:text-blue-600 transition-colors"
            >
              ALL
            </button>
          </div>
        </div>

        {/* Right: action icons + user */}
        <div className="flex items-center gap-1">

          <div className="relative" ref={searchBtnRef}>
            <button
              title="Advanced Search"
              onClick={() => setSearchOpen((v) => !v)}
              className={`w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 transition-colors ${
                searchOpen ? "bg-blue-50 text-blue-600" : "text-gray-500"
              }`}
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
              </svg>
            </button>
            {/* CHANGED: popup is rendered inside relative wrapper, positioned absolute below button */}
            {searchOpen && (
              <SearchPopup
                fields={searchFields}
                onClose={() => setSearchOpen(false)}
                onSearch={handleSearchPopupApply}
              />
            )}
          </div>

          {/* Refresh */}
          <button
            title="Refresh"
            onClick={handleRefresh}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 text-gray-500 transition-colors"
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <polyline points="23 4 23 10 17 10" /><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
            </svg>
          </button>

          {/* Filter panel toggle */}
          <button
            title="Filters"
            onClick={() => setFilterPanelOpen((v) => !v)}
            className={`w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 transition-colors ${
              filterPanelOpen ? "bg-blue-50 text-blue-600" : "text-gray-500"
            }`}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
            </svg>
          </button>

          <button title="Bookmark" className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 text-gray-500 transition-colors">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
            </svg>
          </button>

          {/* User dropdown */}
          <div className="relative" ref={menuRef}>
            <button
              onClick={() => setUserMenuOpen((v) => !v)}
              className="flex items-center gap-2 hover:bg-gray-50 rounded-lg px-2 py-1 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                {fullName[0]?.toUpperCase() || "U"}
              </div>
              <div className="hidden sm:block text-right">
                <div className="text-xs font-semibold text-gray-900 leading-tight">{fullName}</div>
                {subtitle && (
                  <div className="text-[10px] text-gray-400 leading-tight truncate max-w-[140px]">
                    {subtitle}
                  </div>
                )}
              </div>
              <svg
                width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
                className={`text-gray-400 flex-shrink-0 transition-transform ${userMenuOpen ? "rotate-180" : ""}`}
              >
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </button>

            {userMenuOpen && (
              <div className="absolute right-0 top-11 z-50 bg-white border border-gray-100 rounded-xl shadow-xl py-1 min-w-[180px]">
                <MenuItem
                  icon={<PersonIcon />}
                  label="Profile"
                  onClick={() => { router.push(""); setUserMenuOpen(false); }}
                />
                <div className="h-px bg-gray-100 my-1" />
                <MenuItem
                  icon={<LockIcon />}
                  label="Change Password"
                  onClick={() => { router.push("/change-password"); setUserMenuOpen(false); }}
                />
                <div className="h-px bg-gray-100 my-1" />
                {impersonating ? (
                  <MenuItem
                    icon={<LogoutIcon />}
                    label="Return to Admin"
                    onClick={() => { setUserMenuOpen(false); handleRestoreAdmin(); }}
                  />
                ) : (
                  <MenuItem
                    icon={<LogoutIcon />}
                    label="Logout"
                    danger
                    onClick={() => { setUserMenuOpen(false); handleLogout(); }}
                  />
                )}
              </div>
            )}
          </div>

          <button 
          onClick={() => router.push("/dashboard")}
          className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 text-gray-500 transition-colors ml-1">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="3" y1="6" x2="21" y2="6" />
              <line x1="3" y1="12" x2="21" y2="12" />
              <line x1="3" y1="18" x2="21" y2="18" />
            </svg>
            <span className="hidden sm:inline text-xs font-medium ml-1 text-gray-600">Menu</span>
          </button>
        </div>
      </header>

      {filterPanelOpen && (
        <>
          <div
            className="fixed inset-0 z-40 bg-black/10"
            onClick={() => setFilterPanelOpen(false)}
          />
          <div className="fixed top-0 right-0 h-full w-80 bg-white z-50 shadow-2xl flex flex-col">
            <div className="flex items-center justify-between px-5 py-4 bg-blue-600 text-white flex-shrink-0">
              <h3 className="font-bold text-base">Filters</h3>
              <button
                onClick={() => setFilterPanelOpen(false)}
                className="w-7 h-7 flex items-center justify-center rounded-full hover:bg-blue-500 transition-colors"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
            <FilterPanel onApply={handleFilterApply} />
          </div>
        </>
      )}
    </>
  );
}

function MenuItem({ icon, label, onClick, danger }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${
        danger ? "text-gray-600 hover:bg-red-50 hover:text-red-500" : "text-gray-700 hover:bg-gray-50"
      }`}
    >
      <span className="text-gray-400">{icon}</span>
      {label}
    </button>
  );
}

function PersonIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}
function LockIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  );
}
function LogoutIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
      <polyline points="16 17 21 12 16 7" />
      <line x1="21" y1="12" x2="9" y2="12" />
    </svg>
  );
}
