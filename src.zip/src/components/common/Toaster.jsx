"use client";

import { useState, useEffect } from "react";
import { subscribe } from "@/lib/toast";

function ToastIcon({ type }) {
  if (type === "success") {
    return (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
        <polyline points="20 6 9 17 4 12" />
      </svg>
    );
  }
  if (type === "error") {
    return (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
        <circle cx="12" cy="12" r="10" />
        <line x1="12" y1="8" x2="12" y2="12" />
        <line x1="12" y1="16" x2="12.01" y2="16" />
      </svg>
    );
  }
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="16" x2="12" y2="12" />
      <line x1="12" y1="8" x2="12.01" y2="8" />
    </svg>
  );
}

const colorMap = {
  success: "bg-green-50 border-green-200 text-green-800",
  error: "bg-red-50 border-red-200 text-red-700",
  info: "bg-blue-50 border-blue-200 text-blue-700",
};

const iconColorMap = {
  success: "text-green-600",
  error: "text-red-500",
  info: "text-blue-500",
};

export default function Toaster() {
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    const unsub = subscribe((event) => {
      if (event.type === "add") {
        setToasts((prev) => [...prev, event.payload]);
      } else if (event.type === "remove") {
        setToasts((prev) => prev.filter((t) => t.id !== event.id));
      }
    });
    return unsub;
  }, []);

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-[9999] flex flex-col gap-2 pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`flex items-center gap-2.5 px-4 py-3 rounded-xl border shadow-lg text-sm font-medium max-w-sm pointer-events-auto animate-in ${colorMap[t.type] || colorMap.info}`}
          style={{ animation: "slideIn 0.2s ease-out" }}
        >
          <span className={iconColorMap[t.type] || iconColorMap.info}>
            <ToastIcon type={t.type} />
          </span>
          <span>{t.message}</span>
        </div>
      ))}
      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(100%); }
          to { opacity: 1; transform: translateX(0); }
        }
      `}</style>
    </div>
  );
}
