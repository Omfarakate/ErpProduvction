export default function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
        <path d="M18 3 A15 15 0 0 1 33 18" stroke="#ef4444" strokeWidth="5" strokeLinecap="round" fill="none" />
        <path d="M33 18 A15 15 0 0 1 18 33" stroke="#f59e0b" strokeWidth="5" strokeLinecap="round" fill="none" />
        <path d="M18 33 A15 15 0 0 1 3 18" stroke="#22c55e" strokeWidth="5" strokeLinecap="round" fill="none" />
        <path d="M3 18 A15 15 0 0 1 18 3" stroke="#3b82f6" strokeWidth="5" strokeLinecap="round" fill="none" />
        <circle cx="18" cy="18" r="5" fill="#2563eb" />
      </svg>
      <div className="leading-tight">
        <div className="text-[13px] font-bold text-gray-900">Production</div>
        <div className="text-[13px] font-bold text-gray-900">Planning</div>
      </div>
    </div>
  );
}
