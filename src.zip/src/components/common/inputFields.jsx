"use client";

import { useState } from "react";

export default function InputField({
  label,
  id,
  type = "text",
  placeholder,
  value,
  onChange,
  error,
  icon,
  max,
  min,
  ...rest
}) {
  const [showPwd, setShowPwd] = useState(false);

  const inputType =
    type === "password" ? (showPwd ? "text" : "password") : type;

  // Calculate max DOB for 18+ users
  const today = new Date();
  const maxDOB = new Date(
    today.getFullYear() - 18,
    today.getMonth(),
    today.getDate()
  )
    .toISOString()
    .split("T")[0];

  return (
    <div className="flex flex-col gap-1 mb-4">
      <label htmlFor={id} className="text-[13px] font-medium text-gray-800">
        {label}
        <em className="text-red-500 text-xs">*</em>
      </label>

      <div
        className={`flex items-center bg-gray-100 rounded-md border-[1.5px]
        ${
          error
            ? "border-red-400"
            : "border-transparent focus-within:border-blue-500"
        }`}
      >
        <input
          id={id}
          type={inputType}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          max={type === "date" ? maxDOB : max}
          min={min}
          {...rest}
          className="text-black flex-1 px-3.5 py-[10px] bg-transparent outline-none"
        />

        {type === "password" && (
          <button
            type="button"
            onClick={() => setShowPwd((v) => !v)}
            className="pr-3 text-gray-500"
          >
            {showPwd ? "Hide" : "Show"}
          </button>
        )}
      </div>

      {error && <p className="text-red-500 text-xs">{error}</p>}
    </div>
  );
}
// bg-white rounded-2xl border border-gray-100 shadow-sm p-8




{/* <InputField
  label="Date of Birth"
  id="dob"
  type="date"
  value={form.dob}
  onChange={handleChange}
/> */}