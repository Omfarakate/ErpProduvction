import {
  Body,
  Controller,
  Post,
  Req,
  Get,
  Param,
  Query,
  Put,
  Delete,
  UseInterceptors,
  UploadedFile,
} from '@nestjs/common';

import { FileInterceptor } from '@nestjs/platform-express';
import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { UserService } from './services/user.service';
import { UserListService } from './services/user.list.service';
import { UserAddDto } from './dto/userAdd.dto';
import { UserUpdateDto } from './dto/userUpdate.dto';
import { multerConfig } from '../packages/configs/multer.config';
import { commonFileDto } from '../packages/commondtos/commonFile.dto';
import { UserGetService } from './services/user.get.service';

@Controller('user')
export class UserController {
  constructor(
    private readonly userService: UserService,
    private readonly userListService: UserListService,
    private readonly userGetService: UserGetService,
  ) {}

  @Post('user-add')
  @UseInterceptors(FileInterceptor('profImg', multerConfig))
  async createUser(
    @Req() req,
    @Body() body,
    @UploadedFile() file?: Express.Multer.File,
  ) {
    try {
      const dto = plainToInstance(UserAddDto, body);
      const errors = await validate(dto, { whitelist: true });

      if (errors.length > 0) {
        return {
          success: 0,
          message: 'Validation failed',
          errors: errors.map((e) => ({
            field: e.property,
            constraints: e.constraints,
          })),
        };
      }

      if (file?.filename) {
        dto.profImg = file.filename;
      }

      if (file) {
        const fileDto = new commonFileDto();
        fileDto.file = file.mimetype;
        const fileErrors = await validate(fileDto, { whitelist: true });
        if (fileErrors.length > 0) {
          return {
            success: 0,
            message: 'File validation failed',
            errors: fileErrors,
          };
        }
      }

      const params: any = {
        ...dto,
        groupIds: dto.groupId ? [dto.groupId] : [],
      };
      // console.log('Received create request with body:', body);
      // console.log('Received create request with params:', params);

      return await this.userService.startUserInsert(req, params, file);
    } catch (err: any) {
      return { success: 0, message: err.message };
    }
  }

@Put('user-update/:id')
@UseInterceptors(FileInterceptor('profImg', multerConfig))
async updateUser(
  @Param('id') id: number,
  @Req() req,
  @Body() body: UserUpdateDto,
  @UploadedFile() file?: Express.Multer.File,
) {
  // console.log('Received update request with body:', body);
  // console.log('Received update request with body:', params);

  try {
    if (file?.filename) {
      body.profImg = file.filename;
    }

    if (file) {
      const fileDto = new commonFileDto();
      fileDto.file = file.mimetype;

      const errors = await validate(fileDto, { whitelist: true });

      if (errors.length > 0) {
        return {
          success: 0,
          message: 'File validation failed',
          errors,
        };
      }
    }

    return await this.userService.startUserUpdate(
      req,
      Number(id),
      body,
      file,
    );
  } catch (err: any) {
    return {
      success: 0,
      message: err.message,
    };
  }
}

  @Get('user/:id')
  async getUserDetails(@Param('id') id: number) {
    return await this.userListService.startUserDetails({ id });
  }

  @Post('login')
  async login(@Body() body, @Req() req) {
    console.log('Received login request with body:', body);
    return await this.userGetService.startUserLogin(req, body);
  }

  @Get('users-list')
  async getUserList(@Query() query) {
    // console.log('Received users-list request with query:', query);
    return await this.userListService.startUserList(query);
  }

  @Delete('delete-user/:id')
  async deleteUser(@Param('id') id: number) {
    return await this.userService.startUserDelete(id);
  }

  @Post('change-password')
  async changePassword(@Req() req, @Body() body) {
    console.log('Received change password request with body:', body);
    return await this.userService.startChangePassword(req, body);
  }

  @Post('forgot-password')
  async forgotPassword(@Body() body) {
    // console.log('Received forgot password request with body:', body);
    return await this.userService.forgotPassword(body);
  }

  @Post('reset-password')
  async resetPassword(@Body() body) {
    return await this.userService.resetPassword(body);
  }

  @Post('login-as')
  async loginAs(@Body() body) {
    console.log('Received login-as request with body:', body);
    return await this.userGetService.loginAsUser(body);
  }
}
