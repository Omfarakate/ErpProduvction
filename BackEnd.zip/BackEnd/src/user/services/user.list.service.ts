import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { UserEntity } from '../entities/user.entity';
import { GeneralUtilities } from '../../packages/utilities/general.utility';

@Injectable()
export class UserListService {
  constructor(
    @InjectRepository(UserEntity)
    private readonly userRepository: Repository<UserEntity>,

    private readonly generalUtilities: GeneralUtilities,
  ) {}

  async startUserDetails(params) {
    if (!params.id && !params.email) {
      return { success: 0, message: 'ID or Email is required' };
    }
    const response = await this.getUserDetails(params);
    if (response.success === 1) {
      return this.finishSuccess(response);
    }
    return this.finishFailure(response);
  }

  async getUserDetails(params) {
    let return_data: any = {};
    try {
      const queryBuilder = this.userRepository.createQueryBuilder('user');

      queryBuilder
        .leftJoinAndSelect('user.userGroupCompanies', 'ugc')
        .leftJoinAndSelect('ugc.group', 'group')
        .leftJoinAndSelect('ugc.company', 'company');

      if (params.id) {
        queryBuilder.andWhere('user.id = :id', { id: params.id });
      }
      if (params.email) {
        queryBuilder.andWhere('user.email = :email', { email: params.email });
      }

      const data = await queryBuilder.getOne();
      if (!data) throw new Error('User not found');

      return_data = { success: 1, message: 'User details fetched successfully', data };
    } catch (err: any) {
      return_data = { success: 0, message: err.message };
    }
    return return_data;
  }

  async startUserList(params: any) {
    const response = await this.getUserList(params);
    return response;
  }

  async getUserList(params: any) {
    try {
      const page = params.page ? parseInt(params.page) : 1;
      const limit = params.limit ? parseInt(params.limit) : 10;
      const skip = (page - 1) * limit;

      const queryBuilder = this.userRepository.createQueryBuilder('user');

      queryBuilder
        .leftJoinAndSelect('user.userGroupCompanies', 'ugc')
        .leftJoinAndSelect('ugc.group', 'group')
        .leftJoinAndSelect('ugc.company', 'company');

      if (params.search) {
        queryBuilder.andWhere(
          `(user.firstName LIKE :search OR user.lastName LIKE :search OR user.email LIKE :search OR user.phoneNumber LIKE :search OR user.userName LIKE :search)`,
          { search: `%${params.search}%` },
        );
      }

      if (params.email) {
        queryBuilder.andWhere('user.email LIKE :email', { email: `%${params.email}%` });
      }

      if (params.phone_number) {
        queryBuilder.andWhere('user.phoneNumber LIKE :phone', { phone: `%${params.phone_number}%` });
      }

      if (params.user_name) {
        queryBuilder.andWhere('user.userName LIKE :userName', { userName: `%${params.user_name}%` });
      }

      if (params.status) {
        queryBuilder.andWhere('user.isActive = :status', { status: params.status });
      }

      if (params.group) {
        queryBuilder.andWhere('group.groupName LIKE :group', { group: `%${params.group}%` });
      }

      if (params.company) {
        queryBuilder.andWhere('company.companyName LIKE :company', { company: `%${params.company}%` });
      }

      const allowedSortFields = ['id', 'firstName', 'email', 'phoneNumber', 'isActive', 'addedDate'];
      const sortBy = allowedSortFields.includes(params.sort_by) ? params.sort_by : 'id';
      const order = params.order?.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';
      queryBuilder.orderBy(`user.${sortBy}`, order);

      queryBuilder.skip(skip).take(limit);

      const [data, total] = await queryBuilder.getManyAndCount();

      return {
        success: 1,
        message: 'User list fetched successfully',
        data: {
          list: data,
          pagination: {
            total,
            page,
            limit,
            total_pages: Math.ceil(total / limit),
          },
        },
      };
    } catch (err: any) {
      return { success: 0, message: err.message };
    }
  }

  async finishSuccess(params) {
    return {
      settings: {
        success: params.success,
        message: params.message,
        data: params.data || [],
      },
    };
  }

  async finishFailure(params) {
    return { success: 0, message: params.message };
  }
}
