// user.service.ts

import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';

import { UserEntity } from '../entities/user.entity';
import { GroupEntity } from '../../group/entities/group.entity';

import { GeneralUtilities } from '../../packages/utilities/general.utility';
import { UserGroupCompanyEntity } from '../../packages/entity/userGroupCompany.entity';
import { generateOTP } from '../../packages/general/otp/otp';
import { sendOTPEmail } from '../../packages/general/otp/mail';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(UserEntity)
    private readonly userRepository: Repository<UserEntity>,

    @InjectRepository(GroupEntity)
    private readonly groupRepository: Repository<GroupEntity>,

    private readonly general: GeneralUtilities,

    @InjectRepository(UserGroupCompanyEntity)
    private readonly userGroupCompanyRepository: Repository<UserGroupCompanyEntity>,
  ) {}

  async startUserInsert(req, params, file?) {
    const response = await this.insertUser(req, params, file);

    if (response.success === 1) {
      return this.finishSuccess(response, params);
    }

    return this.finishFailure(response);
  }

  async insertUser(req, params, file?) {
    let return_data: any = {};

    try {
      let groups: GroupEntity[] = [];

      if (params.groupIds?.length > 0) {
        groups = await this.groupRepository.findBy({
          id: In(params.groupIds.map(Number)),
        });
      }

      if (groups.length === 0 && params.groupName) {
        let group = await this.groupRepository.findOne({
          where: { groupName: params.groupName },
        });

        if (!group) {
          group = this.groupRepository.create({
            groupName: params.groupName,
            groupCode:
              params.groupName === 'superAdmin'
                ? '1'
                : params.groupName === 'companyAdmin'
                  ? '2'
                  : '3',
          });
          group = await this.groupRepository.save(group);
        }

        groups = [group];
      }

      const companyId = Number(params.companyId);
      if (!companyId) {
        throw new Error('companyId is required');
      }
      console.log('user to be associated :', params);
      const user = {
        firstName: params.firstName,
        middleName: params.middleName,
        lastName: params.lastName,
        userName: params.userName,
        email: params.email,
        password: params.password,
        birthDate: params.birthDate,
        dialCode: params.dialCode || "",
        phoneNumber: params.phoneNumber || "",
        profImg: params.profImg,
        isActive: params.isActive ?? 'Active',
        // Entity column is "AddedBy" (capital A)
        AddedBy: req.user?.id ?? null,
      };
      // console.log('Creating user with data:', user);
      const savedUser = await this.userRepository.save(user);
      // console.log(groups);
      if (groups.length > 0) {
        const mappings = groups.map((group) =>
          this.userGroupCompanyRepository.create({
            user: { id: savedUser.id } as any,
            group: { id: group.id } as any,
            company: { id: companyId } as any,
            addedBy: req.user?.id ?? null,
          }),
        );

        await this.userGroupCompanyRepository.save(mappings);
      }
      console.log('File to be moved:', file);
      if (file) {
        await this.general.moveFile(file, savedUser.id, 'profileImg');
      }

      return_data = {
        success: 1,
        message: 'User inserted successfully',
        data: savedUser,
      };
    } catch (err: any) {
      console.log('Error inserting user:', err);
      return_data = {
        success: 0,
        message: err.message,
      };
    }

    return return_data;
  }

  async startUserUpdate(req, userId: number, params, file?) {
    const response = await this.updateUser(req, userId, params, file);

    if (response.success === 1) {
      return this.finishSuccess(response, params);
    }

    return this.finishFailure(response);
  }

  async updateUser(req, id: number, params, file?) {
    try {
      if (!id) {
        throw new Error('User id is required');
      }

      const updateData: any = {};

      const allowedFields = [
        'firstName',
        'middleName',
        'lastName',
        'userName',
        'email',
        'password',
        'birthDate',
        'phoneNumber',
        'profImg',
        'isActive',
      ];

      allowedFields.forEach((key) => {
        if (params[key] !== undefined) {
          updateData[key] = params[key];
        }
      });

      if (file) {
        updateData.profImg = file.filename;
      }

      updateData.updatedBy = req.user?.id ?? null;
      updateData.updatedDate = new Date();

      const result = await this.userRepository.update(id, updateData);

      if (result.affected === 0) {
        throw new Error('User not found');
      }

      if ((params.groupIds && params.groupIds.length > 0) || params.companyId) {
        const user = await this.userRepository.findOne({
          where: { id },
        });

        if (!user) {
          throw new Error('User not found');
        }

        const groups = await this.groupRepository.findBy({
          id: In(params.groupIds?.map(Number) || []),
        });

        const companyId = Number(params.companyId);

        if (!companyId) {
          throw new Error('companyId is required');
        }

        await this.userGroupCompanyRepository.delete({
          user: { id },
        } as any);

        const mappings = groups.map((group) =>
          this.userGroupCompanyRepository.create({
            user: { id: user.id } as any,
            group: { id: group.id } as any,
            company: { id: companyId } as any,
            updatedBy: req.user?.id ?? null,
          }),
        );
        console.log('Saving user-group-company mappings:', mappings);
        await this.userGroupCompanyRepository.save(mappings);
        console.log('User-group-company mappings saved successfully');
      }

      if (file) {
        await this.general.moveFile(file, id, 'profileImg');
      }

      return {
        success: 1,
        message: 'User updated successfully',
      };
    } catch (err: any) {
      return {
        success: 0,
        message: err.message,
      };
    }
  }

  async startUserDelete(id: number) {
    const response = await this.deleteUser(id);
    return response.success === 1
      ? this.finishSuccess(response)
      : this.finishFailure(response);
  }

  async deleteUser(id: number) {
    let return_data: any = {};
    try {
      await this.userRepository.delete(id);
      return_data = { success: 1, message: 'User deleted successfully' };
    } catch (err: any) {
      return_data = { success: 0, message: err.message };
    }
    return return_data;
  }

  async startChangePassword(req, params) {
    const response = await this.changePassword(req, params);
    return response.success === 1
      ? this.finishSuccess(response)
      : this.finishFailure(response);
  }

  async changePassword(req, params) {
    let return_data: any = {};
    try {
      const user = await this.userRepository.findOne({
        where: { email: params.email },
      });

      console.log('Found params:', params);
      console.log('Found params :',  params.currentPassword);
      console.log('Found params:', typeof params.currentPassword, typeof params.newPassword, typeof params.confirmPassword);

      if (!user) throw new Error('User not found');
      console.log('User found:', user);
      if (user.password !== params.currentPassword) {
        console.log("hello1")
        throw new Error('Current password is incorrect');
      }
      if (params.newPassword !== params.confirmPassword){
        console.log("hello2")
        throw new Error('New password and confirm password do not match');
      }
      user.password = params.newPassword;
      await this.userRepository.save(user);

      return_data = { success: 1, message: 'Password changed successfully' };
    } catch (err: any) {
      return_data = { success: 0, message: err.message };
    }
    return return_data;
  }

  async forgotPassword(params) {
    let return_data: any = {};
    try {
      const user = await this.userRepository.findOne({
        where: { email: params.email },
      });

      if (!user) throw new Error('Email not found');

      const otp = generateOTP();
      const mailResponse = await sendOTPEmail(params.email, otp);

      if (mailResponse.success === 0) throw new Error(mailResponse.message);

      user.otp = otp;
      user.otpExpiry = new Date(Date.now() + 5 * 60 * 1000);
      await this.userRepository.save(user);

      return_data = { success: 1, message: 'OTP sent successfully' };
    } catch (err: any) {
      return_data = { success: 0, message: err.message };
    }
    return return_data;
  }

  async resetPassword(params) {
    let return_data: any = {};
    try {
      if (!params.email || !params.otp || !params.newPassword) {
        throw new Error('Email, OTP, and new password are required');
      }

      const user = await this.userRepository.findOne({
        where: { email: params.email },
      });

      if (!user) throw new Error('User not found');

      if (user.otp !== params.otp) {
        throw new Error('Invalid OTP');
      }

      if (!user.otpExpiry || new Date() > user.otpExpiry) {
        throw new Error('OTP has expired');
      }

      user.password = params.newPassword;
      user.otp = undefined;
      user.otpExpiry = undefined;
      await this.userRepository.save(user);

      return_data = { success: 1, message: 'Password reset successfully' };
    } catch (err: any) {
      return_data = { success: 0, message: err.message };
    }
    return return_data;
  }

  async finishSuccess(params, incomingData?) {
    return {
      settings: {
        success: 1,
        message: params.message,
        data: params.data || [],
        incoming_data: incomingData || {},
      },
    };
  }

  async finishFailure(params) {
    return {
      settings: {
        success: 0,
        message: params.message || "Operation failed",
        data: [],
      },
    };
  }
}
