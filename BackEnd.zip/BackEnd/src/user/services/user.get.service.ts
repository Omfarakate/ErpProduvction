import { Injectable } from '@nestjs/common';
import { UserEntity } from '../entities/user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
@Injectable()
export class UserGetService {
  constructor(
    @InjectRepository(UserEntity)
    protected userTableEntity: Repository<UserEntity>,
  ) {}

  async startUserLogin(req, body) {
    if (!body.email || !body.password) {
      return {
        success: 0,
        message: 'Email and password are required',
      };
    }

    const response = await this.loginUser(body.email, body.password);

    if (response.success === 1) {
      return await this.finishSuccess(response);
    } else {
      return await this.finishFailure(response);
    }
  }

  async loginUser(email: string, password: string) {
    let return_data: any = {};
    try {
      const queryObject = this.userTableEntity;
      const user = await queryObject.findOne({
        where: { email },
      });

      if (!user) {
        return {
          success: 0,
          message: 'User not found',
        };
      }
      if (user.password !== password) {
        return {
          success: 0,
          message: 'Invalid password',
        };
      }

      return_data = {
        success: 1,
        message: 'Login successful',
        data: user,
      };

      return return_data;
    } catch (err: any) {
      return {
        success: 0,
        message: err.message,
      };
    }
  }
  //   async getAllUsers() {
  //     let return_data: any = {};

  //     try {
  //       const queryObject = this.userTableEntity;
  //       const res = await queryObject.find();

  //       return_data = {
  //         success: 1,
  //         message: 'Data Fetched SuccessFully',
  //         data: res,
  //       };
  //       return return_data;
  //     } catch (err: any) {
  //       return_data = {
  //         success: 0,
  //         message: err.message,
  //       };
  //       return return_data;
  //     }
  //   }

  async startUserList(req, params) {
    let response = await this.getUserList(params);
    // if(response.success == 1){
    //     return await this.finishSuccess(response , params)
    // } else{
    //     return await this.finishFailure(response)
    // }
  }

  async getUserList(params) {
    let return_data: any = {};

    try {
      let page = params.page ? parseInt(params.page) : 1;
      let limit = params.limit ? parseInt(params.limit) : 10;
      let skip = (page - 1) * limit;
      console.log(skip);
      const queryBuilder = this.userTableEntity.createQueryBuilder('user');

      let queryObject = this.userTableEntity.createQueryBuilder('u');
      queryObject.select('name as Name');
      queryObject.addSelect('age as Age');
      queryObject.addSelect('isActive as Is_Active');

      let response = await queryObject.getRawMany();
      console.log(response);
      if (params.name) {
        queryBuilder.andWhere('user.name LIKE :name', {
          name: `%${params.name}%`,
        });
      }

      if (params.email) {
        queryBuilder.andWhere('user.email LIKE :email', {
          email: `%${params.email}%`,
        });
      }

      if (params.age) {
        queryBuilder.andWhere('user.age = :age', { age: params.age });
      }

      if (params.is_active !== undefined) {
        queryBuilder.andWhere('user.isActive = :isActive', {
          isActive: params.is_active,
        });
      }

      if (params.from_date && params.to_date) {
        queryBuilder.andWhere('user.addedDate BETWEEN :from AND :to', {
          from: params.from_date,
          to: params.to_date,
        });
      }

      queryBuilder.orderBy('user.id', 'ASC');
      queryBuilder.skip(skip).take(limit);
      // console.log(queryBuilder.getQueryAndParameters())
      const [data, total] = await queryBuilder.getManyAndCount();

      return_data = {
        success: 1,
        message: 'List fetched successfully',
        data: {
          list: data,
          pagination: {
            total: total,
            page: page,
            limit: limit,
            total_pages: Math.ceil(total / limit),
          },
        },
      };
    } catch (err: any) {
      console.log(err);
      return_data = {
        success: 0,
        message: err.message,
      };
    }

    return return_data;
  }
  async finishSuccess(res) {
    let output: any = {
      settings: {
        success: 1,
        data: res,
      },
    };
    return output;
  }
  async finishFailure(res) {
    let output: any = {
      settings: {
        success: 0,
        data: res,
      },
    };
    return output;
  }

  async loginAsUser(body: { adminEmail: string; targetUserId: number }) {
    try {
      const admin = await this.userTableEntity.findOne({ where: { email: body.adminEmail } });
      if (!admin) {
        return { settings: { success: 0, message: 'Admin not found' } };
      }

      // Check if admin is super admin
      const isSuperAdmin = admin.email === "omifarakate@gmail.com";
      if (!isSuperAdmin) {
        return { settings: { success: 0, message: 'Unauthorized: Only super admins can log users' } };
      }

      const target = await this.userTableEntity.findOne({ where: { id: body.targetUserId } });
      if (!target) {
        return { settings: { success: 0, message: 'Target user not found' } };
      }
      return {
        settings: {
          success: 1,
          message: 'Login as user successful',
          data: { adminUser: admin, targetUser: target },
        },
      };
    } catch (err: any) {
      return { settings: { success: 0, message: err.message } };
    }
  }
}
