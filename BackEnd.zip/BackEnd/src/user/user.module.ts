import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserEntity } from './entities/user.entity';
import { UserController } from './user.controller';
import { UserService } from './services/user.service';
import { UserListService } from './services/user.list.service';
import { GeneralUtilities } from '../packages/utilities/general.utility';
import { GroupEntity } from '../group/entities/group.entity';
import { CompanyEntity } from '../company/entity/companies.entity';
import { UserGetService } from './services/user.get.service';
import { UserGroupCompanyEntity } from '../packages/entity/userGroupCompany.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      UserEntity,
      GroupEntity,
      CompanyEntity,
      UserGroupCompanyEntity,
    ]),
  ],
  controllers: [UserController],
  providers: [UserService, UserListService, GeneralUtilities, UserGetService],
  exports: [UserService],
})
export class UserModule {}
