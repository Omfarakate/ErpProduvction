import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  OneToMany,
} from 'typeorm';

import { UserGroupCompanyEntity } from '../../packages/entity/userGroupCompany.entity';

@Entity('users')
export class UserEntity {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  firstName!: string;

  @Column({ nullable: true })
  middleName!: string;

  @Column()
  lastName!: string;

  @Column()
  userName!: string;

  @Column({ unique: true })
  email!: string;

  @Column()
  password!: string;

  @Column({ type: 'date' })
  birthDate!: Date;

  @Column({ nullable: true, default: "" })
  dialCode!: string;
  
  @Column({ nullable: true, default: "" })
  phoneNumber!: string;

  @Column({ nullable: true })
  profImg!: string;

  @Column({ default: 'Active' })
  isActive!: string;

  @Column({ nullable: true })
  otp?: string;

  @Column({ type: 'timestamp', nullable: true })
  otpExpiry?: Date;

  @Column({ name: 'AddedBy', nullable: true })
  AddedBy!: string;

  @Column({ nullable: true })
  updatedBy!: string;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  addedDate!: Date;

  @Column({ type: 'timestamp', nullable: true })
  updatedDate!: Date;

  @OneToMany(() => UserGroupCompanyEntity, (ugc: UserGroupCompanyEntity) => ugc.user)
  userGroupCompanies!: UserGroupCompanyEntity[];
}
