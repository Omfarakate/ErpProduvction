import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import * as dotenv from 'dotenv';
dotenv.config();
import { UserEntity } from './user.entity';
import { GeneralUtilities } from '../../packages/utilities/general.utility';
import { GroupEntity } from '../../group/entities/group.entity';
import { CurrencyEntity } from '../../currency/entity/currency.entity';
import { CountryEntity } from '../../currency/entity/country.entity';
import { CompanyEntity } from '../../company/entity/companies.entity';
import { UserGroupCompanyEntity } from '../../packages/entity/userGroupCompany.entity';

export const typeOrmConfig: TypeOrmModuleOptions = {
  type: 'mysql',
  host: 'localhost',
  port: 3306,
  username: 'root',
  password: 'root',
  database: 'myProductionProject',

  // autoLoadEntities: true,
  entities: [UserEntity, GroupEntity,CurrencyEntity,CountryEntity,CompanyEntity,UserGroupCompanyEntity],

  synchronize: true,
  // logging: true,
};
