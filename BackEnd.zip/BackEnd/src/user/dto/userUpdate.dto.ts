import {
  IsArray,
  IsDateString,
  IsEmail,
  IsInt,
  IsOptional,
  IsString,
} from 'class-validator';

export class UserUpdateDto {
  @IsOptional()
  @IsString()
  firstName?: string;

  @IsOptional()
  @IsString()
  middleName?: string;

  @IsOptional()
  @IsString()
  lastName?: string;

  @IsOptional()
  @IsString()
  userName?: string;

  @IsOptional()
  @IsEmail()
  email?: string;

  @IsOptional()
  @IsDateString()
  birthDate?: string;

  @IsOptional()
  @IsString()
  phoneNumber?: string;

  // single group id
  @IsOptional()
  @IsInt()
  groupId?: number;

  // multiple group ids
  @IsOptional()
  @IsArray()
  groupIds?: number[];

  @IsOptional()
  @IsString()
  groupName?: string;

  @IsOptional()
  @IsString()
  groupCode?: string;

  @IsOptional()
  @IsString()
  profImg?: string;

  @IsOptional()
  @IsString()
  isActive?: string;

  @IsOptional()
  @IsInt()
  companyId?: number;

  @IsOptional()
  @IsDateString()
  updatedDate?: string;
}