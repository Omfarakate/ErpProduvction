import {
  IsEmail,
  IsInt,
  IsOptional,
  IsString,
  MinLength,
} from 'class-validator';
import { Transform } from 'class-transformer';

export class UserAddDto {
  @IsString()
  firstName!: string;

  @IsOptional()
  @IsString()
  middleName?: string;

  @IsString()
  lastName!: string;

  @IsString()
  userName!: string;

  @IsEmail()
  email!: string;

  @IsString()
  @MinLength(6)
  password!: string;

  @IsString()
  birthDate!: string;

  @IsOptional()
  @IsString()
  dialCode?: string;

  @IsOptional()
  @IsString()
  phoneNumber?: string;


  @Transform(({ value }) => (value !== undefined ? Number(value) : undefined))
  @IsInt()
  companyId!: number;


  @Transform(({ value }) => (value !== undefined ? Number(value) : undefined))
  @IsInt()
  groupId!: number;

  @IsOptional()
  @IsString()
  profImg?: string;
}
