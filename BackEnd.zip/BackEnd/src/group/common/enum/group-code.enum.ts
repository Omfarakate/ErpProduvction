export enum GroupCode {
  SUPER_ADMIN = "Super_admin",
  COMPANY_ADMIN = "Company_admin",
}

