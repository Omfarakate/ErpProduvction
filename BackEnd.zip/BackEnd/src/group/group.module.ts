import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GroupEntity } from './entities/group.entity';
import { GroupController } from './group.controller';
import { GroupService } from './service/group.service';
import { GroupListService } from './service/group.list.sevice';
import { GeneralUtilities } from '../packages/utilities/general.utility';

@Module({
  imports: [TypeOrmModule.forFeature([GroupEntity])],

  controllers: [GroupController],

  providers: [GroupService, GroupListService, GeneralUtilities],

  exports: [GroupService, GroupListService],
})
export class GroupModule {}
