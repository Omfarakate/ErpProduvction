import { IsOptional, IsString, IsNumber } from 'class-validator';

export class GroupUpdateDto {
  @IsOptional()
  id!: number;

  @IsOptional()
  @IsString()
  groupName?: string;

  @IsOptional()
  @IsNumber()
  groupCode?: number;
}