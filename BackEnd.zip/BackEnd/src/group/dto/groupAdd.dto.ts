import { IsString, IsNumber } from 'class-validator';

export class GroupAddDto {
  @IsString()
  groupName!: string;

  @IsNumber()
  groupCode!: number;
}

