import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  ManyToMany,
  OneToMany,
} from 'typeorm';

import { UserEntity } from '../../user/entities/user.entity';
import { UserGroupCompanyEntity } from '../../packages/entity/userGroupCompany.entity';

@Entity('groups')
export class GroupEntity {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  groupName!: string;

  @Column()
  groupCode!: string;

  @Column({ default: 'Active' })
  isActive!: string;

  @Column({ nullable: true })
  AddedBy!: string;

  @Column({ nullable: true })
  updatedBy!: string;

  @Column({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP',
  })
  addedDate!: Date;

  @Column({
    type: 'timestamp',
    nullable: true,
  })
  updatedDate!: Date;

  @OneToMany(
    () => UserGroupCompanyEntity,
    (ugc) => ugc.group,
  )
  userGroupCompanies!: UserGroupCompanyEntity[];
}