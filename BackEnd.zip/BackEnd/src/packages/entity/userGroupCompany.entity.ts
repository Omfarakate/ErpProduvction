import {
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  Column,
} from 'typeorm';

import { UserEntity } from '../../user/entities/user.entity';
import { GroupEntity } from '../../group/entities/group.entity';
import { CompanyEntity } from '../../company/entity/companies.entity';

@Entity('user_group_companies')
export class UserGroupCompanyEntity {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ nullable: true })
  addedBy!: string;

  @Column({ nullable: true })
  updatedBy!: string;

  @Column({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP',
  })
  addedDate!: Date;

  @Column({
    type: 'timestamp',
    nullable: true,
  })
  updatedDate!: Date;

  @ManyToOne(() => UserEntity, (user) => user.userGroupCompanies, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'userId' })
  user!: UserEntity;

  @ManyToOne(() => GroupEntity, (group) => group.userGroupCompanies, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'groupId' })
  group!: GroupEntity;

  @ManyToOne(() => CompanyEntity, (company) => company.userGroupCompanies, {
    onDelete: 'CASCADE',
  })
  
  @JoinColumn({ name: 'companyId' })
  company!: CompanyEntity;
}