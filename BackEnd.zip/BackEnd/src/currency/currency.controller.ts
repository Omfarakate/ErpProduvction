import { Controller, Get } from '@nestjs/common';

@Controller('cats')
export class CurrencyController {
  @Get()
  findAll(): string {
    return 'This action returns all ';
  }
}