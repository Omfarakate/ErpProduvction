import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';

import { CurrencyEntity } from './currency.entity';

@Entity('countries')
export class CountryEntity {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  name!: string;

  @Column({ unique: true, length: 2 })
  isoCode!: string;

  @Column()
  currencyId!: number;

//   @ManyToOne(() => CurrencyEntity, (currency) => currency.countries)
//   @JoinColumn({ name: 'currencyId' })
//   currency!: CurrencyEntity;
}
