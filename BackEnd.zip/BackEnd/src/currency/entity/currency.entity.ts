import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  OneToMany,
} from 'typeorm';

// import { CountryEntity } from './country.entity';

@Entity('currencies')
export class CurrencyEntity {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ length: 100 })
  name!: string;

  @Index({ unique: true })
  @Column({ length: 3 })
  code!: string;

  @Column({ nullable: true, length: 255 })
  symbolImg?: string;

  @Column({
    type: 'decimal',
    precision: 18,
    scale: 6,
    default: 1.0,
  })
  exchangeRate!: string;

  @Column({ default: true })
  isActive!: boolean;

  @Column({ nullable: true, length: 100 })
  addedBy?: string;

  @Column({ nullable: true, length: 100 })
  updatedBy?: string;

  @CreateDateColumn({
    type: 'timestamp',
  })
  addedDate!: Date;

  @UpdateDateColumn({
    type: 'timestamp',
  })
  updatedDate!: Date;

//   @OneToMany(() => CountryEntity, (country) => country.currency)
//   countries!: CountryEntity[];
}