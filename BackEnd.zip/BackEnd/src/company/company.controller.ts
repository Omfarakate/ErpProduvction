import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Req,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { CompanyService } from './sevice/company.service';
import { CompanyListService } from './sevice/company.list.service';

@Controller('company')
export class CompanyController {
  constructor(
    private readonly companyService: CompanyService,
    private readonly companyListService: CompanyListService,
  ) {}

  @Post('create')
  @UseInterceptors(FileInterceptor('file'))
  async createCompany(@Req() req, @Body() body, @UploadedFile() file) {
    return this.companyService.startCompanyInsert(req, body, file);
  }

  @Put('update')
  @UseInterceptors(FileInterceptor('file'))
  async updateCompany(@Req() req, @Body() body, @UploadedFile() file) {
    return this.companyService.startCompanyUpdate(req, body, file);
  }

  @Delete(':id')
  async deleteCompany(@Param('id') id: number) {
    return this.companyService.startCompanyDelete(id);
  }

  @Get('all')
  async getAllCompanies() {
    return this.companyListService.getAllCompaniesForDropdown();
  }

  @Get(':id')
  async getCompanyDetails(@Param() params) {
    return this.companyListService.startCompanyDetails(params);
  }

  @Post('list')
  async getCompanyList(@Body() body) {
    return this.companyListService.startCompanyList(body);
  }
}
