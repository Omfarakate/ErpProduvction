import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { CompanyEntity } from './entity/companies.entity';
import { UserGroupCompanyEntity } from '../packages/entity/userGroupCompany.entity';

import { CompanyService } from './sevice/company.service';
import { CompanyListService } from './sevice/company.list.service';

import { GeneralUtilities } from '../packages/utilities/general.utility';
import { CompanyController } from './company.controller';

@Module({
  imports: [TypeOrmModule.forFeature([CompanyEntity, UserGroupCompanyEntity])],
  controllers: [CompanyController],
  providers: [CompanyService, CompanyListService, GeneralUtilities],
  exports: [CompanyService, CompanyListService],
})
export class CompanyModule {}
