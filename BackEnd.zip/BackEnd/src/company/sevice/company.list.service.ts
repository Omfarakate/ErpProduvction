import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { CompanyEntity } from '../entity/companies.entity';

@Injectable()
export class CompanyListService {
  constructor(
    @InjectRepository(CompanyEntity)
    private readonly companyRepository: Repository<CompanyEntity>,
  ) {}

async getAllCompaniesForDropdown() {
  try {
    const list = await this.companyRepository.find();

    console.log(list);

    return { success: 1, data: list };
  } catch (err: any) {
    return { success: 0, message: err.message };
  }
}

  async startCompanyDetails(params) {
    const response = await this.getCompanyDetails(params);
    return response.success === 1
      ? this.finishSuccess(response)
      : this.finishFailure(response);
  }

  async getCompanyDetails(params) {
    try {
      const data = await this.companyRepository.findOne({
        where: { id: params.id, isDeleted: false },
      });
      if (!data) throw new Error('Company not found');
      return { success: 1, message: 'Company details fetched successfully', data };
    } catch (err: any) {
      return { success: 0, message: err.message };
    }
  }

  async startCompanyList(params) {
    const response = await this.getCompanyList(params);
    return response.success === 1
      ? this.finishSuccess(response)
      : this.finishFailure(response);
  }

  async getCompanyList(params) {
    try {
      const page = Number(params.page || 1);
      const limit = Number(params.limit || 10);
      const skip = (page - 1) * limit;

      const qb = this.companyRepository.createQueryBuilder('company');
      qb.where('company.isDeleted = :isDeleted', { isDeleted: false });

      if (params.companyName) {
        qb.andWhere('company.companyName LIKE :companyName', {
          companyName: `%${params.companyName}%`,
        });
      }
      if (params.email) {
        qb.andWhere('company.email LIKE :email', { email: `%${params.email}%` });
      }
      if (params.status) {
        qb.andWhere('company.status = :status', { status: params.status });
      }

      qb.orderBy(
        `company.${params.sort_by || 'id'}`,
        params.order?.toUpperCase() === 'DESC' ? 'DESC' : 'ASC',
      );
      qb.skip(skip).take(limit);

      const [list, total] = await qb.getManyAndCount();

      return {
        success: 1,
        message: 'Company list fetched successfully',
        data: {
          list,
          pagination: {
            total,
            page,
            limit,
            total_pages: Math.ceil(total / limit),
          },
        },
      };
    } catch (err: any) {
      return { success: 0, message: err.message };
    }
  }

  finishSuccess(params) {
    return {
      settings: {
        success: params.success,
        message: params.message,
        data: params.data || [],
      },
    };
  }

  finishFailure(params) {
    return params;
  }
}
