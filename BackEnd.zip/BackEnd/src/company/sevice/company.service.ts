import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { CompanyEntity } from '../entity/companies.entity';
import { GeneralUtilities } from '../../packages/utilities/general.utility';

@Injectable()
export class CompanyService {
  constructor(
    @InjectRepository(CompanyEntity)
    private readonly companyRepository: Repository<CompanyEntity>,
    private readonly general: GeneralUtilities,
  ) {}

  async startCompanyInsert(req, params, file?) {
    const response = await this.insertCompany(req, params, file);

    return response.success === 1
      ? this.finishSuccess(response, params)
      : this.finishFailure(response);
  }

  async insertCompany(req, params, file?) {
    try {
      const company = this.companyRepository.create({
        ...params,
        isActive: params.isActive ?? true,
        addedBy: req.user?.id,
      });

      const saved = await this.companyRepository.save(company);

      const companySaved = Array.isArray(saved) ? saved[0] : saved;

      if (file && companySaved?.id) {
        await this.general.moveFile(file, companySaved.id, 'companyLogo');
      }

      return {
        success: 1,
        message: 'Company inserted successfully',
        data: saved,
      };
    } catch (err: any) {
      return {
        success: 0,
        message: err.message,
      };
    }
  }

  async startCompanyUpdate(req, params, file?) {
    const response = await this.updateCompany(req, params.id, params, file);

    return response.success === 1
      ? this.finishSuccess(response, params)
      : this.finishFailure(response);
  }

  async updateCompany(req, id, params, file?) {
    try {
      const updateData: Partial<CompanyEntity> = {
        ...params,
        updatedBy: req.user?.id,
      };

      if (file) {
        updateData.logo = `file-${Date.now()}`;
      }

      await this.companyRepository.update(id, updateData);

      if (file) {
        await this.general.moveFile(file, id, 'companyLogo');
      }

      return {
        success: 1,
        message: 'Company updated successfully',
      };
    } catch (err: any) {
      return {
        success: 0,
        message: err.message,
      };
    }
  }

  async startCompanyDelete(id: number) {
    const response = await this.deleteCompany(id);

    return response.success === 1
      ? this.finishSuccess(response)
      : this.finishFailure(response);
  }

  async deleteCompany(id: number) {
    try {
      await this.companyRepository.update(id, {
        isDeleted: true,
        isActive: false,
      });

      return {
        success: 1,
        message: 'Company deleted successfully',
      };
    } catch (err: any) {
      return {
        success: 0,
        message: err.message,
      };
    }
  }

  finishSuccess(params, incomingData?) {
    return {
      settings: {
        success: params.success,
        message: params.message,
        data: params.data || [],
        incoming_data: incomingData || {},
      },
    };
  }

  finishFailure(params) {
    return params;
  }
}
