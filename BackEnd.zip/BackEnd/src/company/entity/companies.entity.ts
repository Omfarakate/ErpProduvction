import {
  Column,
  CreateDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

import { UserGroupCompanyEntity } from '../../packages/entity/userGroupCompany.entity';

export enum CompanyStatus {
  ACTIVE = 'Active',
  INACTIVE = 'Inactive',
  BLOCKED = 'Blocked',
}

@Entity('companies')
export class CompanyEntity {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  companyName!: string;

  @Column({
    unique: true,
  })
  companyCode!: string;

  @Column({
    nullable: true,
  })
  tradingName!: string;

  @Column({
    nullable: true,
  })
  logo!: string;

  @Column({
    type: 'text',
    nullable: true,
  })
  description!: string;

  @Column({
    nullable: true,
    unique: true,
  })
  email!: string;

  @Column({
    nullable: true,
  })
  phoneNumber!: string;

  @Column({
    nullable: true,
  })
  website!: string;

  @Column({
    nullable: true,
    unique: true,
  })
  gstinNo!: string;

  @Column({
    nullable: true,
    unique: true,
  })
  panNo!: string;

  @Column({
    nullable: true,
    unique: true,
  })
  registrationNumber!: string;

  @Column({
    type: 'text',
    nullable: true,
  })
  registeredAddress!: string;

  @Column({
    nullable: true,
  })
  country!: string;

  @Column({
    nullable: true,
  })
  state!: string;

  @Column({
    nullable: true,
  })
  city!: string;

  @Column({
    nullable: true,
  })
  pincode!: string;

  @Column({
    nullable: true,
  })
  ownerName!: string;

  @Column({
    nullable: true,
  })
  ownerEmail!: string;

  @Column({
    nullable: true,
  })
  ownerPhoneNumber!: string;

  @Column({
    type: 'text',
    nullable: true,
  })
  ownerAddress!: string;

  @Column({
    type: 'enum',
    enum: CompanyStatus,
    default: CompanyStatus.ACTIVE,
  })
  status!: CompanyStatus;

  @Column({
    default: true,
  })
  isActive!: boolean;

  @Column({
    default: false,
  })
  isDeleted!: boolean;

  @Column({
    nullable: true,
  })
  addedBy!: string;

  @Column({
    nullable: true,
  })
  updatedBy!: string;

  @CreateDateColumn({
    type: 'timestamp',
  })
  addedDate!: Date;

  @UpdateDateColumn({
    type: 'timestamp',
    nullable: true,
  })
  updatedDate!: Date;

  @OneToMany(() => UserGroupCompanyEntity, (ugc) => ugc.company)
  userGroupCompanies!: UserGroupCompanyEntity[];
}
