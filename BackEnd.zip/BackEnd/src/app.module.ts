import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { typeOrmConfig } from './user/entities/typeOrm.config';
import { UserModule } from './user/user.module';
import { GroupModule } from './group/group.module';
import { CompanyModule } from './company/comapny.module';

@Module({
  imports: [
    TypeOrmModule.forRoot(typeOrmConfig),
    UserModule,
    GroupModule,
    CompanyModule
  ],
})
export class AppModule {}